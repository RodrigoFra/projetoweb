<?php
session_start();
require("config.php");

    $sql_ativo=sprintf("select * from ativar;");
    $querry=mysqli_query($ligacao,$sql_ativo);
    $reg_ativo=mysqli_fetch_array($querry);

if($reg_ativo['ativo']==1 and $_SESSION['nivel']!=3){
    header('location:/manutencao.php');
}

if(!isset($_SESSION['maillog'])){
    
    header('location:login.php');
}

if(isset($_POST['back1'])){
    
    header('location:admin.php');
}
   
$sql=sprintf("select * from begincard where mail='%s';",$_SESSION['maillog']);
$res=mysqli_query($ligacao,$sql);
$reg=mysqli_fetch_array($res);

if(isset($_POST['submeter'])){ 
    $erros='';
        if(strlen($_POST['pass'])==0){
            $erros.='ERRO NA PASSWORD <br>';
        }else{
            if($_POST['pass']!=$_POST['rpass']){
                $erros.='AS PASSWORDS NÃO COINCIDEM';
            }
        }
                $password=md5($_POST['pass']);
                    $consulta =sprintf("UPDATE begincard SET pass='%s' WHERE mail='%s'",$password,$_SESSION['maillog']);
                        if(!mysqli_query($ligacao,$consulta)){
                            $erros.="Falha ao alterar os dados";
                        } else {
                            $sucesso="Dados alterados com sucesso";
                        }
}

?>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Landing PAGE Html5 Template">
    <meta name="keywords" content="landing,startup,flat">
    <meta name="author" content="Made By GN DESIGNS">

    <title>Begin Car - Vortex layout</title>

    <!-- // PLUGINS (css files) // -->
    <link href="assets/js/plugins/bootsnav_files/skins/color.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/animate.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/bootsnav.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/overwrite.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.theme.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.transitions.css" rel="stylesheet">
    <link href="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/magnific-popup.css" rel="stylesheet">
    <!--// ICONS //-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--// BOOTSTRAP & Main //-->
    <link href="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/main.css" rel="stylesheet">
</head>

<body>

    <!--======================================== 
           Preloader
    ========================================-->
    <div class="page-preloader">
        <div class="spinner">
            <div class="rect1"></div>
            <div class="rect2"></div>
            <div class="rect3"></div>
            <div class="rect4"></div>
            <div class="rect5"></div>
        </div>
    </div>
      <!--======================================== 
           Header
    ========================================-->

    <!--//** Navigation**//-->
    <nav data-minus-value-desktop="70" data-minus-value-mobile="55" data-speed="1000">

        <div class="container">
            <!-- Start Header Navigation -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" >
                    <img src="assets/img/begincar.png" class="logo" alt="logo" style="width: 150px;">
                </a>
            </div>
            <!-- End Header Navigation -->

 
    <style>
        
        .login-mail {
            border: 1px solid #E9E9E9;
            margin-bottom: 2em;
            padding: 0.5em 1em;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        
        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 50%;
        }
         
        td,
        th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
         
        h1 {
            color: #44c5ee;
        }
        
        tab { padding-right: 100em; }  
    </style>
   
    <center>
        <script>
            $(document).ready(function() {
                $("#gfg").on("keyup", function() {
                    var value = $(this).val().toLowerCase();
                    $("#geeks tr").filter(function() {
                        $(this).toggle($(this).text()
                        .toLowerCase().indexOf(value) > -1)
                    });
                });
            });
        </script>
  </center>
                        
        <div class="col-md-5 col-md-offset-1">
                    <form method="post" class="signup-form">
                        <h2 class="text-center">Alterar Password</h2>
                        <hr>
                        <div class="login-mail">
                            <b>E-mail:</b>  <?php echo $_SESSION['maillog'];?>
                        </div>
                        <div class="form-group">
                            <input type="password" name="pass" class="form-control" placeholder="Introduza a nova password" required="required">
                        </div>
                        <div class="form-group">
                            <input type="password" name="rpass" class="form-control" placeholder="Coloque novamente a password" required="required">
                        </div>
                        <div class="form-group text-center">
                            <button type="submit" name="submeter" class="btn btn-blue btn-block">Guardar Alterações</button>
                               <br>
                                <?php 
                                    if(isset($_POST['submeter'])){    
                                        if($erros!=''){
                                ?>          <div class='alert alert-danger' align='center'>
                                                <?php echo $erros="Volte a inserir<br>";?>
                                                <br>
                                            </div>
                                <?php
                                        } else {
                                            if(isset($_POST['submeter'])){
                                ?>              <div class='alert alert-success' align='center'>
                                                    <?php echo $sucesso="Password alterada com sucesso<br>";?>
                                                </div>
                                <?php
                                            }
                                        }
                                    }
                                ?>       
                        </div>
                    </form>
                </div><br><tab></tab>   
            <hr>
            <form class="contact-form" method="post">
                <p align="left"><button type="submit" name="back1" class="btn btn-blue" style="width: 10%;">Voltar</button></p>
            </form>
        </div>
    
 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
    <script src="assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>
    <script src="assets/js/plugins/bootsnav_files/js/bootsnav.js"></script>
    <script src="assets/js/plugins/typed.js-master/typed.js-master/dist/typed.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js"></script>
    <script src="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
    <script src="assets/js/main.js"></script>
    
    </nav>  
    </body>
</html> 