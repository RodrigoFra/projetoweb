<?php
session_start();
require('config.php'); 

    $sql_ativo=sprintf("select * from ativar;");
    $querry=mysqli_query($ligacao,$sql_ativo);
    $reg_ativo=mysqli_fetch_array($querry);

if($reg_ativo['ativo']==1 and $_SESSION['nivel']!=3){
    header('location:/manutencao.php');
}

if(isset($_POST['back1'])){
    
    header('location:produtos.php');
}

if($_SESSION['nivel']!=3){
    header('location:login.php');
}


    if(isset($_POST['confirmar'])){
        $sql_apaga=sprintf("delete from categorias where id=%d;",$_POST['id']);
        if(mysqli_query($ligacao,$sql_apaga)){
                        $sucesso = 'CATEGORIA APAGADA COM SUCESSO';
                        }
                    }else{
                        $erros = 'CATEGORIA NÃO FOI APAGADA';
                    }

    $sql_lista=sprintf("select * from categorias order by categ asc;");
    $res_lista=mysqli_query($ligacao,$sql_lista);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Landing PAGE Html5 Template">
    <meta name="keywords" content="landing,startup,flat">
    <meta name="author" content="Made By GN DESIGNS">

    <title>Begin Car - Vortex layout</title>

    <!-- // PLUGINS (css files) // -->
    <link href="assets/js/plugins/bootsnav_files/skins/color.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/animate.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/bootsnav.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/overwrite.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.theme.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.transitions.css" rel="stylesheet">
    <link href="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/magnific-popup.css" rel="stylesheet">
    <!--// ICONS //-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--// BOOTSTRAP & Main //-->
    <link href="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/main.css" rel="stylesheet">
</head>

<style>
    tab { padding-right: 100em; }
    
    table {
        font-family: arial, sans-serif;
        border-collapse: collapse;
        margin-left: auto;
        margin-right: auto;
    }
         
    td,th {
        border: 1px solid #44c5ee;
        text-align: left;
        padding: 8px;
    }
         
    h1 {
        color: #44c5ee;
    }

</style>
    
<body>
    
    <?php
    if(isset($_POST['apagar'])){
        ?>
        <form method="post">
            <h3>CONFIRMA QUE QUER APAGAR A CATEGORIA <?php echo $_POST['subcateg']; ?></h3>
            <input type="submit" name="confirmar" class="btn btn-blue" value="CONFIRMAR" >
            <input type="submit" name="cancelar" class="btn btn-blue" value="CANCELAR" >
            <input type="hidden" name="id" value="<?php echo $_POST['id']; ?>">
            <input type="hidden" name="id" value="<?php echo $_POST['id']; ?>">
        </form><br>
        <?php
    } else {
        ?> 

    
    <!--======================================== 
           Preloader
    ========================================-->
    <div class="page-preloader">
        <div class="spinner">
            <div class="rect1"></div>
            <div class="rect2"></div>
            <div class="rect3"></div>
            <div class="rect4"></div>
            <div class="rect5"></div>
        </div>
    </div>
    <!--======================================== 
           Header
    ========================================-->

    <!--//** Navigation**//-->
    <nav data-minus-value-desktop="70" data-minus-value-mobile="55" data-speed="1000">

        <div class="container">
            <!-- Start Header Navigation -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" >
                    <img src="assets/img/begincar.png" class="logo" alt="logo" style="width: 150px;">
                </a>
            </div>
            <!-- End Header Navigation -->
            <form method="post" class="signup-form" enctype="multipart/form-data">
                <div class="col-md-6 col-md-offset-1">
                        <h2 class="text-center">Adicionar Categorias</h2>
                        <hr>
                            <center>
                              <select name="categ1">
                                  <option value="Sistema de travagem">Sistema de travagem</option>
                                  <option value="Filtros">Filtros</option>
                                  <option value="Suspensão & direção">Suspensão & direção</option>
                                  <option value="Embraiagem/Transmissão">Embraiagem/Transmissão</option>
                                  <option value="Distribuição">Distribuição</option>
                                  <option value="Outras peças">Outras peças</option>
                                  <option value="Óleos e fluidos">Óleos e fluidos</option>
                                  <option value="Pneus">Pneus</option> 
                              </select>
                            </center><br>
                        <div class="form-group">
                            <input type="text" name="adic_categ" class="form-control" placeholder="Nome da SubCategoria" required="required">
                    </div>
                </div>
                <br>
                    <div class="col-md-6 col-md-offset-3">
                        <div class="form-group text-center">
                            <button type="submit" name="submeter" class="btn btn-blue" style="width: 50%;">Enviar</button>
                        </div>
                    </div>
            </form>
        </div>
            <?php
            
                if(isset($_POST['submeter'])){
                    $erros='';
                    if(strlen($_POST['adic_categ'])==0){
                        $erros.= ' ERRO AO ADICIONAR CATEGORIA <br>';
                    }
                    if($erros==''){
                        $sql_inserir=sprintf("insert into categorias (categ,subcateg) values ('%s','%s');",$_POST['categ1'],$_POST['adic_categ']);

                        if(mysqli_query($ligacao,$sql_inserir)){
                    ?>
                        <div class="alert alert-success" align="center">
                            <?php echo $sucesso='DADOS ENVIADOS COM SUCESSO'; ?>
                        </div>
                    <?php
                        } else {
                            $erros='ERRO AO GUARDAR OS DADOS';
                    ?><div class="alert alert-danger" align="center"><?php echo $erros ; ?></div><?php
                        } 
                    }
                }
            
            ?>
        <hr>
        
    <center>
        <h2>Lista de Categorias</h2>
        <br>
        
        <b>Procurar:
          <input id="myInput" onkeyup="myFunction()" type="text" placeholder="insira um nome">
        </b>
        <br>
        <br>
        <table id="myTable">
            <tr>
                <th>Categorias</th>
                <th>Subcategorias</th>
                <th>Remover</th>
            </tr>
            <tbody >
               <?php
                while($reg_lista=mysqli_fetch_array($res_lista)){
                    ?>
                    <tr>
                        <td align="center" width="250px"><?php echo $reg_lista['categ']; ?></td>
                        <td align="center" width="250px"><?php echo $reg_lista['subcateg']; ?></td>
                        <td>
                            <form method="post">
                                <button type="submit" name="apagar" class="btn btn-blue" style="width: 100%;">Remover</button>
                                <input type="hidden" name="id" value="<?php echo $reg_lista['id']; ?>">
                                <input type="hidden" name="subcateg" value="<?php echo $reg_lista['subcateg']; ?>">
                            </form>
                        </td>
                    </tr>
            <?php
                }
                    if(isset($_POST['confirmar'])){
                        if(isset($sucesso)){
            ?>              <div class='alert alert-success'>
                                <?php echo $sucesso; ?>
                            </div> <br>
            <?php
                    }
                        if(isset($_POST['confirmar'])){
                            if(isset($erros)){
            ?>
                                <div class='alert alert-danger'>
                                    <?php echo $erros; ?>
                                </div>      
            <?php            
                            }
                        }
                    }
                ?>
            </tbody>
        </table>
 
        <script>
            function myFunction() {
              // Declare variables
              var input, filter, table, tr, td, i, txtValue;
              input = document.getElementById("myInput");
              filter = input.value.toUpperCase();
              table = document.getElementById("myTable");
              tr = table.getElementsByTagName("tr");

              // Loop through all table rows, and hide those who don't match the search query
              for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td")[1];
                if (td) {
                  txtValue = td.textContent || td.innerText;
                  if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                  } else {
                    tr[i].style.display = "none";
                  }
                }
              }
            }
        </script>
<?php
    }
?>
    </center>
        <form class="contact-form" method="post">
                 <button type="submit" name="back1" class="btn btn-blue" style="width: 10%;">Voltar</button>
        </form>
     <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
    <script src="assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>
    <script src="assets/js/plugins/bootsnav_files/js/bootsnav.js"></script>
    <script src="assets/js/plugins/typed.js-master/typed.js-master/dist/typed.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js"></script>
    <script src="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
    <script src="assets/js/main.js"></script>
    </nav>
    </body>
</html>