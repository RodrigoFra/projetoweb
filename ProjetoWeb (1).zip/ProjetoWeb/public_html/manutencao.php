<?php
session_start();
require("config.php");
?>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Begin Car - Manutenção</title>
  <link href="https://fonts.googleapis.com/css?family=Titillium+Web" rel="stylesheet">
  <style>
    body{
      font-family: 'Titillium Web', sans-serif;
      color: #666666;
      text-align: center;
    }
    .box{
      background-color: #fff;
    }
    #title {
      font-size: 30px;
      margin-top: 25px;
    }
    #descricao{
      font-size:20px;
      margin: 20px auto;
    }
    #logo {
      margin-top: 25px;
      max-width: 365px;
      height: auto;
    }
    #logo-task {
      width: 75px;
    }
  </style>
</head><br><br>
<body>
  <div class="box">
      <div align="center">
      <img src="assets/img/manutencao.jpg" width="1000px" height="700px" align="middle">
      </div>
  </div>
</body>
</html>