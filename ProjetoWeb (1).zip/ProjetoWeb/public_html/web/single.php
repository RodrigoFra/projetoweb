<?php
session_start();
require('config.php');

    $sql_ativo=sprintf("select * from ativar;");
    $querry=mysqli_query($ligacao,$sql_ativo);
    $reg_ativo=mysqli_fetch_array($querry);

if($reg_ativo['ativo']==1 and $_SESSION['nivel']!=3){
    header('location:/manutencao.php');
}

if(isset($_GET['id'])){
    $sql_lista=sprintf("select * from produtos where id=%d;",$_GET['id']);
    $res_lista=mysqli_query($ligacao,$sql_lista);
    $reg_lista=mysqli_fetch_array($res_lista);
} else {
    header("location:index.php");
}

if(isset($_POST['btn_carrinho'])){
        $erros='';
       
            $sql_carr=sprintf("select * from loja_inf where mail='%s' and estado=1;",$_SESSION['maillog']);
            $res_carr=mysqli_query($ligacao,$sql_carr);
            $num_carr=mysqli_num_rows($res_carr);

            if($num_carr==0){
                $sql_inserir=sprintf("insert into loja_inf (mail) values ('%s');",$_SESSION['maillog']);
                if(!mysqli_query($ligacao,$sql_inserir)){
                    $erros= 'FALHA NA GRAVAÇÃO DOS DADOS';
                } else {
                    $sucesso='DADOS GRAVADOS COM SUCESSO';
                }
            }
            $sql_venda=sprintf("select * from loja_inf where mail='%s' and estado=1;",$_SESSION['maillog']);
            $res_venda=mysqli_query($ligacao,$sql_venda);
            $num_venda=mysqli_fetch_array($res_venda);

            $sql_carr2=sprintf("select * from loja_detalhes where mail='%s' and ref='%s' and id_venda=%d;",$_SESSION['maillog'],$reg_lista['ref'],$num_venda['id_venda']);
            $res_carr2=mysqli_query($ligacao,$sql_carr2); 
            $num_carr2=mysqli_num_rows($res_carr2);
    
            if($num_carr2==0){
    
                $sql_prod=sprintf("insert into loja_detalhes (id_venda, mail, ref, nome_produto, ficheiro, quant, preco_produto) values (%d, '%s', '%s', '%s', '%s', 1, %f);", $num_venda['id_venda'],$_SESSION['maillog'],$reg_lista['ref'],$reg_lista['nome_prod'],$reg_lista['ficheiro'],$reg_lista['preco']);
            } else {
                $reg_carr2=mysqli_fetch_array($res_carr2);
                $quantidade=$reg_carr2['quant']+1;
                $sql_prod=sprintf("update loja_detalhes set quant=%d where id=%d;",$quantidade,$reg_carr2['id']);
            }

            if(!mysqli_query($ligacao,$sql_prod)){
                $erros= 'FALHA NA GRAVAÇÃO DOS DADOS';
            } else {
                $sucesso='DADOS GRAVADOS COM SUCESSO';
            }
    }

?>
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Begin Car - Sistema de Travagem</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Classic Style Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script src="js/jquery.min.js"></script>
<!-- //js -->
<!-- cart -->
<script src="js/simpleCart.min.js"></script>
<!-- cart -->
<!-- for bootstrap working -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<!-- animation-effect -->
<link href="css/animate.min.css" rel="stylesheet"> 
<script src="js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->
<link href='//fonts.googleapis.com/css?family=Cabin:400,500,600,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,300,700,900' rel='stylesheet' type='text/css'></head>
	
<body>
    <input type="hidden" name="categ" value="<?php 'categ' ?>">
<style>
    tab { padding-right: 8em; }  
    tab1 { padding-right: 1em; } 
    
    .cart_div span {
        font-size: 13px;
        line-height: 6px;
        padding: 1px;
        position: absolute;
        top: 10px;
        color: #fff;
        width: 9px;
        height: 16px;
        text-align: center;
    }
    
    .clean {
        padding: 0;
        border: none;
        background: none;
    }
</style>
<!-- header -->
	<div class="header">
        <div class="header-grid-1">
            <div class="container">
				<div class="header-left animated wow fadeInLeft" data-wow-delay=".5s">
					<ul>
					    <li><i class="glyphicon glyphicon-headphones"></i>Apoio ao cliente 24/7</li>
						<li><i class="glyphicon glyphicon-envelope" ></i><a href="mailto:info@begincar.com">info@begincar.com</a></li>
						<li><i class="glyphicon glyphicon-earphone" ></i>261 338 465</li>
						
					</ul>
				</div>
				<div class="header-right animated wow fadeInRight" data-wow-delay=".5s">
				    <div class="header-right1">
				        <ul><tab></tab>
				            <li><i class="glyphicon glyphicon-user" ></i><a href="login.php">Conta</a></li>
                                <div class="header-right2">
                                    <a href="checkout.php">
                                        <p><img src="images/cart.png" /></p>
                                    </a>
                                        <div class="cart_div"><tab1></tab1>
                                    <a href="checkout.php">        
                                            <span>
                                               <?php
                                                    require('soma-carrinho.php');
                                                ?>
                                            </span>
                                    </a>
                                        </div>
                                </div>
					   </ul>
				    </div>
                 <div class="clearfix"> </div>
				</div>
                 <div class="clearfix"> </div>
			</div>
        </div>
			<div class="container">
			<div class="logo-nav">
				
					<nav class="navbar navbar-default">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header nav_2">
						<button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						 <div class="navbar-brand logo-nav-left ">
							<h1 class="animated wow pulse" data-wow-delay=".5s"><a href="index.php">Begin<span>Car</span></a></h1>
						</div>


					</div> 
					<div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
						<ul class="nav navbar-nav">
							<!-- Mega Menu -->
							<li class="dropdown">
								<a href="" class="dropdown-toggle" data-toggle="dropdown">Peças Auto <b class="caret"></b></a>
								<ul class="dropdown-menu multi">
									<div class="row">
										<div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<h6>Sistema de Travagem</h6>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Pastilhas de travão</button></li>
                                                <input type="hidden" value="Pastilhas de travão" name="categ">
                                                </form>
												<form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Discos de Travão</button></li>
                                                <input type="hidden" value="Discos de travão" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Pinça de travão</button></li>
                                                <input type="hidden" value="Pinça de travão" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Jogo de travões</button></li>
                                                <input type="hidden" value="Jogo de travões" name="categ">
                                                </form>
											</ul>
										</div>
                                        <div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<h6>Filtros</h6>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Filtro de ar</button></li>
                                                <input type="hidden" value="Filtro de ar" name="categ">
                                                </form>
												<form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Filtro de óleo</button></li>
                                                <input type="hidden" value="Filtro de óleo" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Filtro de combustível</button></li>
                                                <input type="hidden" value="Filtro de combustível" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Filtro de habitáculo</button></li>
                                                <input type="hidden" value="Filtro de habitáculo" name="categ">
                                                </form>
											</ul>
										</div>
										<div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<h6>Suspensão & direção</h6>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Amortecedores</button></li>
                                                <input type="hidden" value="Amortecedores" name="categ">
                                                </form>
												<form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Barra Estabilizadora</button></li>
                                                <input type="hidden" value="Barra Estabilizadora" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Braço de suspensão</button></li>
                                                <input type="hidden" value="Braço de suspensão" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Rotula de direção</button></li>
                                                <input type="hidden" value="Rotula de direção" name="categ">
                                                </form>
											</ul><br><br>
										</div>
                                        <div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<h6>Embraiagem/Transmissão</h6>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Kit de embraiagem</button></li>
                                                <input type="hidden" value="Kit de embraiagem" name="categ">
                                                </form>
												<form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Veio de transmissão</button></li>
                                                <input type="hidden" value="Veio de transmissão" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Caixa de velocidades</button></li>
                                                <input type="hidden" value="Caixa de velocidades" name="categ">
                                                </form>
											</ul>
										</div>
                                        <div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<h6>Distribuição</h6>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Velas</button></li>
                                                <input type="hidden" value="Velas" name="categ">
                                                </form>
												<form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Kit de distribuição</button></li>
                                                <input type="hidden" value="Kit de distribuição" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Correia de distribuição</button></li>
                                                <input type="hidden" value="Correia de distribuição" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Bobina de ignição</button></li>
                                                <input type="hidden" value="Bobina de ignição" name="categ">
                                                </form>
											</ul>
										</div>
                                        <div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<h6>Outras peças</h6>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Elevador do vidro</button></li>
                                                <input type="hidden" value="Elevador do vidro" name="categ">
                                                </form>
												<form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Alternador</button></li>
                                                <input type="hidden" value="Alternador" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Amortecedores da Mala</button></li>
                                                <input type="hidden" value="Braço de suspensão" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Iluminação / Sinalização</button></li>
                                                <input type="hidden" value="Rotula de direção" name="categ">
                                                </form>
											</ul>
										</div>
                                        
										<div class="clearfix"></div>
									</div>
									
								</ul>
							</li>
                            <li><a>
                                <form method="post" action="loja_products.php">
                                    <button class="clean" type="submit">Pneus</button>
                                    <input type="hidden" value="Pneus" name="categ">
                                </form>
                            </a></li>
							<li><a href="contact.php">Contacto</a></li>
						</ul>
					</div>
					</nav>
				</div>
				
		</div>
	</div>
<!-- //header -->
<!--banner-->
<div class="banner-top">
	<div class="container">
		<h2 class="animated wow fadeInLeft" data-wow-delay=".5s"><?php echo $reg_lista['tipo_peca']; ?></h2>
		<h3 class="animated wow fadeInRight" data-wow-delay=".5s"><a href="index.php">Inicio</a><label>/</label><?php echo $reg_lista['tipo_peca']; ?></h3>
		<div class="clearfix"> </div>
	</div>
</div>
	<!--content-->
		<div class="product">
			<div class="container">
		<div class="col-md-3 product-bottom ">
			<!--categories-->
			<div class="categories animated wow fadeInUp animated" data-wow-delay=".5s" >
					<h3>Categorias</h3>
                <?php
                        $sql_categ=sprintf("select * from produtos where tipo_peca='%s';",$_GET['categ']);
                        $res_categ=mysqli_query($ligacao,$sql_categ);
                        $reg_categ=mysqli_fetch_array($res_categ);
                
                    ?>
				    <ul class="cate">
                        <form method="post" action="loja_products.php">
                            <li><i class="glyphicon glyphicon-menu-right" ></i><button class="clean" type="submit">Sistema de travagem</button></li>
                            <input type="hidden" value="Pastilhas de travão" name="categ">
                        </form>
                        
                        <form method="post" action="loja_products.php">
                            <li><i class="glyphicon glyphicon-menu-right" ></i><button class="clean" type="submit">Filtros</button></li>
                            <input type="hidden" value="Filtro de ar" name="categ">
                        </form>
                        
                        <form method="post" action="loja_products.php">
                            <li><i class="glyphicon glyphicon-menu-right" ></i><button class="clean" type="submit">Suspensão & direção</button></li>
                            <input type="hidden" value="Amortecedores" name="categ">
                        </form>
                           
                        <form method="post" action="loja_products.php">
                            <li><i class="glyphicon glyphicon-menu-right" ></i><button class="clean" type="submit">Embraiagem/Transmissão</button></li>
                            <input type="hidden" value="Kit de embraiagem" name="categ">
                        </form>
                        
                           
                        <form method="post" action="loja_products.php">
                            <li><i class="glyphicon glyphicon-menu-right" ></i><button class="clean" type="submit">Distribuição</button></li>
                            <input type="hidden" value="Velas" name="categ">
                        </form>
                        
                        <form method="post" action="loja_products.php">
                            <li><i class="glyphicon glyphicon-menu-right" ></i><button class="clean" type="submit">Outras peças</button></li>
                            <input type="hidden" value="Elevador do vidro" name="categ">
                        </form>
                           
                        <form method="post" action="loja_products.php">
				            <li><i class="glyphicon glyphicon-menu-right" ></i><button class="clean" type="submit">Óleos e fluidos</button></li>
                            <input type="hidden" value="Óleo do motor" name="categ">
                        </form>
                           
                        <form method="post" action="loja_products.php">
				            <li><i class="glyphicon glyphicon-menu-right" ></i><button class="clean" type="submit">Pneus</button></li>
                            <input type="hidden" value="Pneus" name="categ">
                        </form>
					</ul>
				</div>
		<!--//menu-->
		<!--price-->
				<!--<div class="price animated wow fadeInUp animated" data-wow-delay=".5s" >
					<h3>Price Range</h3>
					<div class="price-head">
					<div class="col-md-6 price-head1">
                                        <div class="price-top1">
                                            <span class="price-top">$</span>
                                            <input type="text"  value="0">
                                        </div>
                                    </div>
									<div class="col-md-6 price-head2">
                                        <div class="price-top1">
                                            <span class="price-top">$</span>
                                            <input type="text"  value="500">
                                        </div>
                                    </div>
									<div class="clearfix"></div>
                                    </div>
                                    </div>
			<!--//price-->
			<!--colors-->
			<!--<div class="colors animated wow fadeInLeft animated" data-wow-delay=".5s" >
					<h3>Colors</h3>

                                        <div class="color-top">
                                            <ul>
											<li><a href="#"><i></i></a></li>
												<li><a href="#"><i class="color1"></i></a></li>
												<li><a href="#"><i class="color2"></i></a></li>
												<li><a href="#"><i class="color3"></i></a></li>
												<li><a href="#"><i class="color4"></i></a></li>
												<li><a href="#"><i class="color5"></i></a></li>
												<li><a href="#"><i class="color6"></i></a></li>
												<li><a href="#"><i class="color7"></i></a></li>
											</ul>
                                        </div>
                                    </div>
									
                                 
			<!--//colors-->
			<!--<div class="sellers animated wow fadeInDown" data-wow-delay=".5s">
					
								<h3 class="best">BEST SELLERS</h3>
					<div class="product-head">
					<div class="product-go">
						<div class=" fashion-grid">
									<a href="single.php"><img class="img-responsive " src="images/pcc.jpg" alt=""></a>
									
								</div>
							<div class=" fashion-grid1">
								<h6 class="best2"><a href="single.php">Lorem ipsum </a></h6>
								<span class=" price-in1"> <del>$50.00</del>$40.00</span>
								<p>The standard chunk of Lorem Ipsum used</p>
							</div>
								
							<div class="clearfix"> </div>
							</div>
							<div class="product-go">
						<div class=" fashion-grid">
									<a href="single.php"><img class="img-responsive " src="images/pcc1.jpg" alt=""></a>
									
								</div>
							<div class=" fashion-grid1">
								<h6 class="best2"><a href="single.php">Lorem ipsum </a></h6>
								<span class=" price-in1"> <del>$50.00</del>$40.00</span>
								<p>The standard chunk of Lorem Ipsum used</p>
							</div>
							<div class="clearfix"> </div>
							</div>
							
							</div>
				</div>
				<!---->
 	</div>
        <div class="col-md-9 animated wow fadeInRight" data-wow-delay=".5s">
            <div class="col-md-5 grid-im">
                    <div class="flexslider">
                          <ul class="slides">
                            <li data-thumb="<?php echo $reg_lista['ficheiro']; ?>" class="img-responsive">
                                <div class="thumb-image"> <img src="<?php echo $reg_lista['ficheiro']; ?>" data-imagezoom="true" class="img-responsive2"> </div>
                            </li>
                            <li data-thumb="<?php echo $reg_lista['ficheiro2']; ?>" class="img-responsive">
                                 <div class="thumb-image"> <img src="<?php echo $reg_lista['ficheiro2']; ?>" data-imagezoom="true" class="img-responsive2"> </div>
                            </li>
                            <li data-thumb="<?php echo $reg_lista['ficheiro3']; ?>" class="img-responsive">
                               <div class="thumb-image"> <img src="<?php echo $reg_lista['ficheiro3']; ?>" data-imagezoom="true" class="img-responsive2"> </div>
                            </li> 
                          </ul>
                    </div>
	       </div>	
<div class="col-md-7 single-top-in">
						<div class="span_2_of_a1 simpleCart_shelfItem">
				<h3><?php echo $reg_lista['nome_prod']; ?></h3>
				<p class="in-para"><?php echo $reg_lista['ref']; ?></p>
			    <div class="price_single">
				  <span class="reducedfrom item_price"><?php echo number_format($reg_lista['preco'],2); ?>€</span>
                    <form method="post">
                    <div class="form-group text-right">
                    <button type="submit" name="btn_carrinho" class="btn btn-1 btn-info item_add">Adicionar ao carrinho</button>
                    </div>
                    </form>
				 <div class="clearfix"></div>
				</div>
				
				 
			   
			<div class="clearfix"> </div>
			</div>
		   <!----- tabs-box ---->
		<div class="sap_tabs">	
				     <div id="horizontalTab" style="display: block; width: 85%; margin: 0px;">
						  <ul class="resp-tabs-list">
						  	  <li class="resp-tab-item " aria-controls="tab_item-0" role="tab"><span>Descrição</span></li>
                              <li class="resp-tab-item " aria-controls="tab_item-2" role="tab"><span>Detalhes do produto</span></li>
							  <li class="resp-tab-item" aria-controls="tab_item-2" role="tab"><span>Avaliações</span></li>
							  <div class="clearfix"></div> 
						  </ul>				  	 
							<div class="resp-tabs-container">
							    <h2 class="resp-accordion resp-tab-active" role="tab" aria-controls="tab_item-0"><span class="resp-arrow">Descrição</span></h2><div class="tab-1 resp-tab-content resp-tab-content-active" aria-labelledby="tab_item-0" style="display:block">
									<div class="facts">
									  <p ><?php echo $reg_lista['descricao']; ?></p>        
							        </div>

							    	</div>
							      <h2 class="resp-accordion" role="tab" aria-controls="tab_item-1"><span class="resp-arrow"></span>Detalhes do produto</h2>
                                <div class="tab-1 resp-tab-content" aria-labelledby="tab_item-1">
										<div class="facts1">
					
						<div class="color"><p>Tipo de peça</p>
							<span ><?php echo $reg_lista['tipo_peca']; ?></span>
							<div class="clearfix"></div>
						</div>
						<div class="color">
							<p>Em stock</p>
							<span ><?php echo $reg_lista['stock']; ?></span>
							<div class="clearfix"></div>
						</div>
					        
			 </div>

								</div>									
							      <h2 class="resp-accordion" role="tab" aria-controls="tab_item-2"><span class="resp-arrow"></span>Reviews</h2>
                                <div class="tab-1 resp-tab-content" aria-labelledby="tab_item-2">
									 <div class="comments-top-top">
				<div class="top-comment-left">
					<img class="img-responsive" src="images/co.png" alt="">
				</div>
				<div class="top-comment-right">
					<h6><a>Hélder</a> - 1 de Janeiro, 2020</h6>
					
									<p>Excelente!</p>
				</div>
				<div class="clearfix"> </div>
				<!--<a class="add-re" href="single.php">Add Review</a>-->
			</div>
							 </div>
					      </div>
					 </div>
					 <script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
		    <script type="text/javascript">
			    $(document).ready(function () {
			        $('#horizontalTab').easyResponsiveTabs({
			            type: 'default', //Types: default, vertical, accordion           
			            width: 'auto', //auto or any width like 600px
			            fit: true   // 100% fit in a container
			        });
			    });
			   </script>	
<!---->
					</div>
			
</div>
                
<!----->
<div class="clearfix"> </div>
        </div>

		
			<div class="clearfix"></div>
			</div>			
		</div>
				<!--//products-->
    
	<div class="clearfix"></div><br>
    
<!-- footer -->
	<div class="footer">
		<div class="container">
		<div class="footer-top">
		<div class="clearfix"> </div>
		</div>
			<div class="footer-grids">
				<div class="col-md-4 footer-grid animated wow fadeInLeft" data-wow-delay=".5s">
					<h3>Sobre Nós</h3>
					<p>A Begin Car é uma empresa que comercializa todo o tipo de peças automóveis para todo o tipo de veículos ligeiros.<span>Com o melhor preço, qualidade e serviço do mercado.</span></p>
				</div>
				<div class="col-md-4 footer-grid animated wow fadeInLeft" data-wow-delay=".6s">
					<h3>Os nossos contactos</h3>
					<ul>
						<li><i class="glyphicon glyphicon-map-marker" ></i>Rua Doutor Alberto Martins Santos, <span>2540-087 Bombarral, PT</span></li>
						<li class="foot-mid"><i class="glyphicon glyphicon-envelope" ></i><a href="mailto:info@begincar.com">info@begincar.com</a></li>
						<li><i class="glyphicon glyphicon-earphone" ></i>261 338 465</li>
					</ul>
				</div>
				<div class="col-md-4 footer-grid animated wow fadeInLeft" data-wow-delay=".7s">
				<h3>Deseja receber novidades? </h3>
				<form method=post>
					<input type="text" placeholder="Email"  required="required">
					<input type="submit" value="Enviar">
				</form>
				</div>
                <div class="col-md-2 footer-top2">
		              <a href="contact.php">Contacte-nos</a>
		         </div>
			
				<div class="clearfix"> </div>
			</div>
			
			<div class="copy-right animated wow fadeInUp" data-wow-delay=".5s">
                <p>BeginCar, &copy 2019 All rights reserved </p>
			</div>
		</div>
	</div>
<!-- //footer -->
<script src="js/imagezoom.js"></script>

	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script defer src="js/jquery.flexslider.js"></script>
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />

<script>
// Can also be used with $(document).ready()
$(window).load(function() {
  $('.flexslider').flexslider({
    animation: "slide",
    controlNav: "thumbnails"
  });
});
</script>


</body>
</html>