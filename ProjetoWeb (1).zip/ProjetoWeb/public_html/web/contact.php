<?php
session_start();
require('config.php');

    $sql_ativo=sprintf("select * from ativar;");
    $querry=mysqli_query($ligacao,$sql_ativo);
    $reg_ativo=mysqli_fetch_array($querry);

if($reg_ativo['ativo']==1 and $_SESSION['nivel']!=3){
    header('location:/manutencao.php');
}
?>
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Begin Car - Store</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Classic Style Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script src="js/jquery.min.js"></script>
<!-- //js -->
<!-- cart -->
<script src="js/simpleCart.min.js"></script>
<!-- cart -->
<!-- for bootstrap working -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<!-- animation-effect -->
<link href="css/animate.min.css" rel="stylesheet"> 
<script src="js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->
<link href='//fonts.googleapis.com/css?family=Cabin:400,500,600,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,300,700,900' rel='stylesheet' type='text/css'></head>
	
<style>
    tab { padding-right: 8em; }  
    tab1 { padding-right: 1em; } 
    
    .cart_div span {
        font-size: 13px;
        line-height: 6px;
        padding: 1px;
        position: absolute;
        top: 10px;
        color: #fff;
        width: 9px;
        height: 16px;
        text-align: center;
    }
    
    .alert {
        width: 40%;
        text-align: center;
        margin-left: 250px;
    }
</style> 
    
<body>
<!-- header -->
	<div class="header">
        <div class="header-grid-1">
            <div class="container">
				<div class="header-left animated wow fadeInLeft" data-wow-delay=".5s">
					<ul>
					    <li><i class="glyphicon glyphicon-headphones"></i>Apoio ao cliente 24/7</li>
						<li><i class="glyphicon glyphicon-envelope" ></i><a href="mailto:info@begincar.com">info@begincar.com</a></li>
						<li><i class="glyphicon glyphicon-earphone" ></i>261 338 465</li>
						
					</ul>
				</div>
				<div class="header-right animated wow fadeInRight" data-wow-delay=".5s">
				    <div class="header-right1">
				        <ul><tab></tab>
				            <li><i class="glyphicon glyphicon-user" ></i><a href="login.php">Conta</a></li>
                                <div class="header-right2">
                                    <a href="checkout.php">
                                        <p><img src="images/cart.png" /></p>
                                    </a>
                                        <div class="cart_div"><tab1></tab1>
                                    <a href="checkout.php">        
                                            <span>
                                               <?php
                                                    require('soma-carrinho.php');
                                                ?>
                                            </span>
                                    </a>
                                        </div>
                                </div>
					   </ul>
				    </div>
                 <div class="clearfix"> </div>
				</div>
                 <div class="clearfix"> </div>
			</div>
        </div>
    </div>
<!-- //header -->
<!--banner-->
<div class="banner-top">
	<div class="container">
		<h2 class="animated wow fadeInLeft" data-wow-delay=".5s">Contacto</h2>
		<h3 class="animated wow fadeInRight" data-wow-delay=".5s"><a href="index.php">Inicio</a><label>/</label>Contacto</h3>
		<div class="clearfix"> </div>
	</div>
</div>
<!-- contact -->
	<div class="contact">
		<div class="container">
		
			
			<div class="col-md-8 contact-grids1 animated wow fadeInRight" data-wow-delay=".5s">
				<form method="post">
						<div class="contact-form2">
							<h4>Nome</h4>
							
								<input type="text" placeholder="" required="">
							
						</div>
				
						<div class="contact-form2">
							<h4>Email</h4>
						
								<input type="email" name="email" placeholder="" required="">
						
						</div>
						<div class="contact-form2">
							<h4>Assunto</h4>
						
								<input type="text" name="assunto" placeholder="" required="">
						
						</div>
					
			
				<div class="contact-me ">
					<h4>Mensagem</h4>
				
						<textarea type="text" name="mensagem" placeholder="" required=""> </textarea>
						</div>
						<input type="submit" name="enviar" value="Enviar" ><br>
                    <?php
                    if(isset($_POST['enviar'])){
                        require 'smtp/PHPMailerAutoload.php';
                        require  'smtp/class.phpmailer.php' ;

                            if(isset($_POST['assunto']) && !empty($_POST['assunto'])){
                                $assunto = $_POST['assunto'];
                            } 

                            if(isset($_POST['mensagem']) && !empty($_POST['mensagem'])){
                                $mensagem = $_POST['mensagem'];
                            }

                              if(isset($_POST['email']) && !empty($_POST['email'])){
                                $email = $_POST['email'];
                            }


                            $mail = new PHPMailer; 



                            $mail->isHTML(true);

                            //$mail->SetFrom('ivogames2002@gmail.com', 'Destinatario');


                            $mail->Subject = utf8_decode($assunto);
                            $mail->Body = $mensagem;
                            $mail->AltBody = strip_tags($mensagem);
                            $mail->addAddress('210100324@esg.ipsantarem.pt', 'Remetente');
                            $mail->SetFrom($email);

                            if(!$mail->send()) {
                                echo 'Não foi possivel enviar a mensagem. <br>'; 
                                echo 'Erro: '.$mail->ErrorInfo;
                            } else {
                            ?>
                                <div class='alert alert-success'>
                                <?php echo $sucesso="Mensagem Enviada" ?>
                                </div>
                        <?php
                            }
                    }
                    ?>
				</form>
			</div>
			
			<div class="col-md-4 contact-grids">
				<div class=" contact-grid animated wow fadeInLeft" data-wow-delay=".5s">
					<div class="contact-grid1">
						<div class="contact-grid2 ">
							<i class="glyphicon glyphicon-map-marker" aria-hidden="true"></i>
						</div>
						<div class="contact-grid3">
							<h4>Morada</h4>
							<p>Rua Doutor Alberto Martins Santos, <span>2540-087 Bombarral, PT</span></p>
						</div>
					</div>
				</div>
				<div class=" contact-grid animated wow fadeInUp" data-wow-delay=".5s">
					<div class="contact-grid1">
						<div class="contact-grid2 contact-grid4">
							<i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>
						</div>
						<div class="contact-grid3">
							<h4>Telefone</h4>
							<p>261 338 465</p>
						</div>
					</div>
				</div>
				<div class=" contact-grid animated wow fadeInRight" data-wow-delay=".5s">
					<div class="contact-grid1">
						<div class="contact-grid2 contact-grid5">
							<i class="glyphicon glyphicon-envelope" aria-hidden="true"></i>
						</div>
						<div class="contact-grid3">
							<h4>Email</h4>
							<p><a href="mailto:info@begincar.com">info@begincar.com</a></p>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>

<!-- footer -->
	<div class="footer">
		<div class="container">
		<div class="footer-top">
		<div class="clearfix"> </div>
		</div>
			<div class="footer-grids">
				<div class="col-md-4 footer-grid animated wow fadeInLeft" data-wow-delay=".5s">
					<h3>Sobre Nós</h3>
					<p>A Begin Car é uma empresa que comercializa todo o tipo de peças automóveis para todo o tipo de veículos ligeiros.<span>Com o melhor preço, qualidade e serviço do mercado.</span></p>
				</div>
				<div class="col-md-4 footer-grid animated wow fadeInLeft" data-wow-delay=".6s">
					<h3>Os nossos contactos</h3>
					<ul>
						<li><i class="glyphicon glyphicon-map-marker" ></i>Rua Doutor Alberto Martins Santos, <span>2540-087 Bombarral, PT</span></li>
						<li class="foot-mid"><i class="glyphicon glyphicon-envelope" ></i><a href="mailto:info@begincar.com">info@begincar.com</a></li>
						<li><i class="glyphicon glyphicon-earphone" ></i>261 338 465</li>
					</ul>
				</div>
				<div class="col-md-4 footer-grid animated wow fadeInLeft" data-wow-delay=".7s">
				<h3>Deseja receber novidades? </h3>
				<form method=post>
					<input type="text" placeholder="Email"  required="required">
					<input type="submit" name="enviar" value="Enviar">
				</form>
				</div>

			
				<div class="clearfix"> </div>
			</div>
			
			<div class="copy-right animated wow fadeInUp" data-wow-delay=".5s">
                <p>BeginCar, &copy 2019 All rights reserved </p>
			</div>
		</div>
	</div>
<!-- //footer -->
</body>
</html>