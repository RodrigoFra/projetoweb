$('#procura').keypress(function (e) {
 var key = e.which;
 if(key == 13)  // the enter key code
  {   
     $("#form1").submit();
  }
});