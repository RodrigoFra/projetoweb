<?php
session_start();
require('config.php');

    $sql_ativo=sprintf("select * from ativar;");
    $querry=mysqli_query($ligacao,$sql_ativo);
    $reg_ativo=mysqli_fetch_array($querry);

if($reg_ativo['ativo']==1 and $_SESSION['nivel']!=3){
    header('location:/manutencao.php');
}

if(!isset($_SESSION['normal'])){
    $_SESSION['normal']=1;
}

if(!isset($_SESSION['metodo'])){
    $_SESSION['metodo']=1;
}

$erros='';

if(isset($_POST['normal'])){
    if($_POST['normal']=='option1'){
        $_SESSION['normal']=1;
    }
    if($_POST['normal']=='option2'){
        $_SESSION['normal']=2;
    }
    if($_POST['normal']=='option3'){
        $_SESSION['normal']=3;
    }
}

if(isset($_POST['metodo'])){
    if($_POST['metodo']=='option4'){
        $_SESSION['metodo']=1;
    }
    if($_POST['metodo']=='option5'){
        $_SESSION['metodo']=2;
    }
}

    $sql_lista=sprintf("select * from loja_detalhes where mail='%s' and estado=1;",$_SESSION['maillog']);
    $res_lista=mysqli_query($ligacao,$sql_lista);

if(isset($_POST['submeter'])){
    $erros='';
    if(strlen($_POST['fname'])==0){
        $erros.= ' INTRODUZA O SEU PRIMEIRO NOME <br>';
    }
    if(strlen($_POST['lname'])==0){
        $erros.= ' INTRODUZA O SEU ÚLTIMO NOME <br>';
    }
    if(strlen($_POST['fmorada'])==0){
        $erros.= ' INTRODUZA A SUA MORADA <br>';
    }
    if(strlen($_POST['distrito'])==0){
        $erros.= ' INTRODUZA O DISTRITO <br>';
    }
    if(strlen($_POST['cidade'])==0){
        $erros.= ' INTRODUZA A CIDADE <br>';
    }
    if(strlen($_POST['codigo_postal'])==0){
        $erros.= ' INTRODUZA O SEU CÓDIGO POSTAL <br>';
    }
    if(strlen($_POST['nr_tel'])==0){
        $erros.= ' INTRODUZA O NÚMERO DO TELEMÓVEL <br>';
    }
    if(strlen($_POST['mail'])==0){
        $erros.= ' INTRODUZA O SEU EMAIL <br>';
    } else {
           if(!strpos($_POST['mail'], '@')){
               $erros.= ' FALTA O @ NO EMAIL <br>';
           } 
           if(!strpos($_POST['mail'], '.')){
                $erros.= ' FALTA O .(PONTO) NO EMAIL <br>';
            }
    }
    if($_SESSION['metodo']==1){
        $tipo_pagamento='Cartao de credito';
            if(strlen($_POST['nr_cartao'])==0){
                $erros.= ' INTRODUZA O NÚMERO DO CARTÃO <br>';
            }
            if(strlen($_POST['data_val'])==0){
                $erros.= ' INTRODUZA A DATA DE VALIDADE <br>';
            }
            if(strlen($_POST['cvv'])==0){
                $erros.= ' INTRODUZA O CVV <br>';
            }
            if(strlen($_POST['nome_cartao'])==0){
                $erros.= ' INTRODUZA O NOME DO CARTÃO <br>';
            }
    }
    
    if($erros==''){
        
            $sql_man4=sprintf("select * from loja_inf where mail='%s' and estado=1;",$_SESSION['maillog']);
            $res_man4=mysqli_query($ligacao,$sql_man4);
            $reg_man4=mysqli_fetch_array($res_man4);
        
            $sql_inserir=sprintf("insert into loja_pagamento (id_venda,tipo_pagamento,mail,morada,cidade) values (%d, '%s', '%s', '%s', '%s');",$reg_man4['id_venda'],$tipo_pagamento,$_POST['mail'], $_POST['fmorada'], $_POST['cidade']); 

            if(!mysqli_query($ligacao,$sql_inserir)){
                $erros = 'FALHA NA GRAVAÇÃO DOS DADOS';
            } else{
                $sucesso = 'DADOS GRAVADOS COM SUCESSO';
            }
        
            $sql_man2=sprintf("select * from loja_inf where mail='%s';",$_SESSION['maillog']);
            $res_man2=mysqli_query($ligacao,$sql_man2);
            $reg_man2=mysqli_fetch_array($res_man2);
             
            $sql_confirm=sprintf("update loja_inf set estado=0 where mail='%s' and estado=1;",$_SESSION['maillog']);
                if(!mysqli_query($ligacao,$sql_confirm)){
                    $erros="FALHA AO CONFIRMAR A COMPRA";
                } else {
                    $sucesso="COMPRA EFETUADA COM SUCESSO";
                }
            
            $sql_man3=sprintf("select * from loja_detalhes where mail='%s';",$_SESSION['maillog']);
            $res_man3=mysqli_query($ligacao,$sql_man3);
            $reg_man3=mysqli_fetch_array($res_man3);
             
            $sql_confirm3=sprintf("update loja_detalhes set estado=0 where mail='%s' and estado=1;",$_SESSION['maillog']);
                if(!mysqli_query($ligacao,$sql_confirm3)){
                    $erros="FALHA AO CONFIRMAR A COMPRA";
                } else {
                    $sucesso="COMPRA EFETUADA COM SUCESSO";
                }
     }
}

    $sql_info=sprintf("select * from begincard where mail='%s';",$_SESSION['maillog']);
    $res_info=mysqli_query($ligacao,$sql_info);
    $reg_info=mysqli_fetch_array($res_info);


?>

<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Begin Car - Pagamento</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Classic Style Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script src="js/jquery.min.js"></script>
<!-- //js -->
<!-- cart -->
<script src="js/simpleCart.min.js"></script>
<!-- cart -->
<!-- for bootstrap working -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<!-- animation-effect -->
<link href="css/animate.min.css" rel="stylesheet"> 
<script src="js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->
<link href='//fonts.googleapis.com/css?family=Cabin:400,500,600,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,300,700,900' rel='stylesheet' type='text/css'>
<script type="text/javascript">             
        function isNumberKey(evt){
            var charCode = (evt.which) ? evt.which : evt.keyCode
            //if(charCode==46)return true;
            if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
                return false;

                return true;

            }
</script>
</head>
    
	
<style>
    tab { padding-right: 8em; }
    tab1 { padding-right: 1em; }
    
    .cart_div span {
        font-size: 13px;
        line-height: 6px;
        padding: 1px;
        position: absolute;
        top: 10px;
        color: #fff;
        width: 9px;
        height: 16px;
        text-align: center;
    }
    
    .title-left {
        font-size: 16px;
        border-bottom: 3px solid #010101;
        margin-bottom: 8px;
        margin-left: 15px;
        width: 95%;
    }
    
    .title-left1 {
        font-size: 16px;
        border-bottom: 3px solid #010101;
        margin-bottom: 20px;
        margin-left: 15px;
        width: 95%;
    }
    
    p.right {
        text-align: right;
    } 
    
    .item-specs{
        padding-left: 50px;
        flex: 1;
        font-size: 15px;
        color: black;
        font-weight: 700;
        overflow: hidden;
        letter-spacing: inherit;
    }
    
    .item-specs1{
        padding-left: 50px;
        flex: 1;
        font-size: 13px;
        color: grey;
        font-weight: 700;
        overflow: hidden;
        letter-spacing: inherit;
    }
    
    .total{
        padding-left: 50px;
    }
    
    .paycards{
        width: 39px;
        height: 27px;
        display: inline-block;
        background-image: url(images/visa.png);
        background-repeat: no-repeat;
        vertical-align: middle;
        opacity: .7;
    }
    
    .pay {
      border: none;
      color: white;
      padding: 0.7em 2em;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 16px;
      margin-top: 25px;
      cursor: pointer;
      background-color: #44c5ee;
    }
    
    .payment span{
        color: #fff;
        background: #44c5ee;
        text-decoration: none;
        padding: 0.5em 1em;
        font-size: 1em;
        display: inline-block;
        margin-top: 1em;
    }
</style>
    
<body>
<!-- header -->
	<div class="header">
        <div class="header-grid-1">
            <div class="container">
				<div class="header-left animated wow fadeInLeft" data-wow-delay=".5s">
					<ul>
					    <li><i class="glyphicon glyphicon-headphones"></i>Apoio ao cliente 24/7</li>
						<li><i class="glyphicon glyphicon-envelope" ></i><a href="mailto:info@begincar.com">info@begincar.com</a></li>
						<li><i class="glyphicon glyphicon-earphone" ></i>261 338 465</li>
						
					</ul>
				</div>
				<div class="header-right animated wow fadeInRight" data-wow-delay=".5s">
				    <div class="header-right1">
				        <ul><tab></tab>
				            <li><i class="glyphicon glyphicon-user" ></i><a href="login.php">Conta</a></li>
                                <div class="header-right2">
                                    <a href="checkout.php">
                                        <p><img src="images/cart.png" /></p>
                                    </a>
                                        <div class="cart_div"><tab1></tab1>
                                    <a href="checkout.php">        
                                            <span>
                                               <?php
                                                    require('soma-carrinho.php');
                                                ?>
                                            </span>
                                    </a>
                                        </div>
                                </div>
					   </ul>
				    </div>
                 <div class="clearfix"> </div>
				</div>
                 <div class="clearfix"> </div>
			</div>
        </div>
    </div>
<!-- //header -->
<!--banner-->
<div class="banner-top">
	<div class="container">
		<h2 class="animated wow fadeInLeft" data-wow-delay=".5s">Envio e Pagamento</h2>
		<h3 class="animated wow fadeInRight" data-wow-delay=".5s"><a href="index.php">Inicio</a><label>/</label>Envio e Pagamento</h3>
		<div class="clearfix"> </div>
	</div>
</div>
<!-- contact -->
	<div class="login">
		<div class="container">
		<form method="post">
			<div class="col-sm-6 col-lg-6 mb-3 login-do1 animated wow fadeInLeft" data-wow-delay=".5s">
                <div class="title-left1"><h3>Informação do Envio</h3></div>
                <div class="col-md-12 mb-3" style="font-size: 15px; color:#730d0d";>
                    <center><b>Introduza primeiro a opção de envio e o método de pagamento que deseja!</b></center>
                </div><br><br>
                <div class="col-md-6 mb-3"> 
                    <label>Primeiro Nome</label>
				    <div class="login-mail-1">
				        <input type="text" name="fname" value="<?php echo $reg_info['nome']?>" required="">
				    </div>
			     </div>
                <div class="col-md-6 mb-3">  
                    <label>Último Nome</label>
                    <div class="login-mail-1">
                        <input type="text" name="lname" value="<?php echo $reg_info['apelido']?>" required="">
                    </div>
                 </div><br><br><br><br>
                <div class="col-md-12 mb-3">  
                    <label>1ª Morada <i>(nome da rua, número da porta)</i></label>
                    <div class="login-mail-1">
                        <input type="text" name="fmorada" required="">
                    </div>
                 </div><br><br><br><br>
                <div class="col-md-12 mb-3">  
                    <label>2ª Morada <i>(Opcional)</i></label>
                    <div class="login-mail-1">
                        <input type="text">
                    </div>
                 </div><br><br><br><br>
                <div class="col-md-6 mb-3">  
                    <label>Distrito</label>
				    <div class="login-mail-1">
				        <input type="text" name="distrito" required="">
				    </div>
			     </div>
                <div class="col-md-6 mb-3">  
                    <label>Cidade</label>
                    <div class="login-mail-1">
                        <input type="text" name="cidade" required="">
                    </div>
                 </div><br><br><br>
                <div class="col-md-6 mb-3">  
                    <label>Código Postal</label>
				    <div class="login-mail-1">
				        <input type="text" name="codigo_postal" required onkeypress="return isNumberKey(event);">
				    </div>
			     </div><br><br><br><br>
                <div class="title-left"><h3>Contacto</h3></div>
                 <div class="col-md-12 mb-3">  
                    <label>Número do telemóvel</label>
				    <div class="login-mail-1">
				        <input type="text" name="nr_tel" required="" maxlength="9" onkeypress="return isNumberKey(event);">
				    </div>
			     </div><br><br><br><br>
                <div class="col-md-12 mb-3">  
                    <label>E-mail</label>
				    <div class="login-mail-1">
				        <input type="text" name="mail"  value="<?php echo $reg_info['mail'] ?>" required="">
				    </div>
			     </div><br><br><br><br>
                <div class="title-left"><h3>Opções de Envio</h3></div>
                 <div class="col-md-12 mb-3">
                    <input type="radio" id="normal" name="normal" value="option1" <?php if($_SESSION['normal']==1){ ?>  checked <?php } ?> onclick="submit();"> 
                     <label for="normal">Entrega normal<i>(5-10 dias úteis)</i></label><span style="margin-left: 238px;">Grátis</span>
			     </div><br>
                <div class="col-md-12 mb-3">
                    <input type="radio" id="expresso" name="normal" value="option2" <?php if($_SESSION['normal']==2){ ?>  checked <?php } ?> onclick="submit();">
                    <label for="expresso">Entrega Expresso<i>(3-5 dias úteis)</i></label><span style="margin-left: 240px;">10€</span>
			     </div><br>
                <div class="col-md-12 mb-3">
                    <input type="radio" id="jato" name="normal" value="option3" <?php if($_SESSION['normal']==3){ ?>  checked <?php } ?> onclick="submit();">
                    <label for="jato">Entrega Jato<i>(próximo dia útil)</i></label><span style="margin-left: 258px;">25€</span>
			     </div><br><br>
                <div class="title-left"><h3>Método de Pagamento</h3></div>
                <div class="col-md-12 mb-3">
                    <input type="radio" id="cartao" name="metodo" value="option4" <?php if($_SESSION['metodo']==1){ ?>  checked <?php } ?> onclick="submit();">  
                     <label for="cartao">Cartão de crédito ou débito</label>
			     </div><br>
                <div class="col-md-12 mb-3">
                    <input type="radio" id="paypal" name="metodo" value="option5" <?php if($_SESSION['metodo']==2){ ?>  checked <?php } ?> onclick="submit();"> 
                     <label for="metodo">Paypal</label>
			     </div><br><br>
                <?php if($_SESSION['metodo']==1){ ?>
                <div class="col-md-8 mb-3">  
                    <label>Número do cartão</label>
				    <div class="login-mail-1">
				        <input type="text" name="nr_cartao" required="" maxlength="19">
				    </div>
			     </div>
                <div class="col-md-5 mb-3">  
                    <label>Data de Validade</label><i>(MM/YY)</i>
                    <div class="login-mail-1">
                        <input type="text" name="data_val" required="" maxlength="5">
                    </div>
                 </div>
                <div class="col-md-3 mb-3">  
                    <label>CVV</label>
                    <div class="login-mail-1">
                        <input type="text" name="cvv" required="" maxlength="3" onkeypress="return isNumberKey(event);">
                    </div>
                 </div>
                <div class="col-md-8 mb-3">  
                    <label>Nome no cartão</label>
				    <div class="login-mail-1">
				        <input type="text" name="nome_cartao" required="">
				    </div>
			     </div>
                <div class="col-md-8 mb-3">
                    <div>
                        <button type="submit" name="submeter" class="pay">Finalizar Compra</button>
                    </div>
                 </div>
                <?php
                    } else {
                ?>
                <div class="col-md-8 mb-3">
                    <div class="payment">
                        <a href="https://www.paypal.com/pt/signin"><span style="margin-top: 0em;">&emsp;&emsp;&emsp;Paypal&emsp;&emsp;&emsp;</span></a>
                    </div>
                 </div>
                <?php
                    }
                ?>
            </div>
			<div class="col-md-4 login-do animated wow fadeInRight" data-wow-delay=".5s">
				<div class="title-left"><h3>Carrinho</h3></div>
                <?php 
                    $sub_total=0;
                    $iva=0;
                    $preco_final=0;
                
                    if($_SESSION['normal']==1){
                        $portes=0;
                    }
                    if($_SESSION['normal']==2){
                        $portes=10;
                    }
                    if($_SESSION['normal']==3){
                        $portes=25;
                    }
                
                    while($reg_lista=mysqli_fetch_array($res_lista)){
                        $preco_quant=$reg_lista['quant']*$reg_lista['preco_produto'];
                        $sub_total+=$preco_quant;
                        $iva=$sub_total * 0.23; 
                        $preco_final=$sub_total + $portes + $iva;  
                ?>
                <div class="row1">
                    <div class="col-md-3">
                    <img src="<?php echo $reg_lista['ficheiro']; ?>" width="100px" height="100px" alt="">
                    </div>
                    <div class="col-md-9">
                    <span class="item-specs"><?php echo $reg_lista['nome_produto']; ?></span><br>
                    <span class="item-specs1"><?php echo $reg_lista['ref']; ?></span><br>
                    <span class="item-specs1">Qty: <?php echo $reg_lista['quant']; ?></span><br>
                    <span class="item-specs1">Preço: <?php echo $reg_lista['preco_produto']; ?>€</span>
                    
                    </div>
                    <br><br><br><br><br>
                </div>
                <?php
                    }
                ?>
                <div class="title-left"><h3>Fatura da encomenda</h3></div>
                    <div class="price-details" style="padding-left:20px;">
                        <span>Total em peças</span>
                        <span class="total1"><?php echo $sub_total ;?>€</span>
                        <span>Portes</span>
                        <span class="total1"><?php echo $portes ;?> €</span>
                        <span>Iva</span>
                        <span class="total1"><?php echo number_format($iva,2) ;?>€</span>
                        <div class="clearfix"></div>				 
                    </div>	
                    <ul class="total_price" style="padding-left:20px;">
                        <li class="last_price"> <h4>TOTAL</h4></li>	
                        <li class="last_price"><span><?php echo number_format($preco_final,2) ;?>€</span></li>
                        <div class="clearfix"> </div>
                    </ul><br>
                    <?php
                        if(isset($_POST['submeter'])){
                            if($erros==''){
                    ?>          <div class='alert alert-success'>
                                    <?php echo $sucesso = 'Pagamento efetuado com sucesso'; ?>
                                </div> <br>
                    <?php
                            } else {
                    ?>          <div class='alert alert-danger'>
                                    <?php echo $erros = 'Verifique se os dados estão corretos'; ?>
                                </div>      
                    <?php            
                            }
                        }
                    ?>
			</div>
			<div class="clearfix"> </div>
			</form>
		</div>
	</div>
    <br><br><br><br><br>

<!-- footer -->
	<div class="footer">
		<div class="container">
		<div class="footer-top">
		<div class="clearfix"> </div>
		</div>
			<div class="footer-grids">
				<div class="col-md-4 footer-grid animated wow fadeInLeft" data-wow-delay=".5s">
					<h3>Sobre Nós</h3>
					<p>A Begin Car é uma empresa que comercializa todo o tipo de peças automóveis para todo o tipo de veículos ligeiros.<span>Com o melhor preço, qualidade e serviço do mercado.</span></p>
				</div>
				<div class="col-md-4 footer-grid animated wow fadeInLeft" data-wow-delay=".6s">
					<h3>Os nossos contactos</h3>
					<ul>
						<li><i class="glyphicon glyphicon-map-marker" ></i>Rua Doutor Alberto Martins Santos, <span>2540-087 Bombarral, PT</span></li>
						<li class="foot-mid"><i class="glyphicon glyphicon-envelope" ></i><a href="mailto:info@begincar.com">info@begincar.com</a></li>
						<li><i class="glyphicon glyphicon-earphone" ></i>261 338 465</li>
					</ul>
				</div>
				<div class="col-md-4 footer-grid animated wow fadeInLeft" data-wow-delay=".7s">
				<h3>Deseja receber novidades? </h3>
				<form method=post>
					<input type="text" placeholder="Email"  required="required">
					<input type="submit" value="Enviar">
				</form>
				</div>
                <div class="col-md-2 footer-top2">
		              <a href="contact.php">Contacte-nos</a>
		         </div>
			
				<div class="clearfix"> </div>
			</div>
			
			<div class="copy-right animated wow fadeInUp" data-wow-delay=".5s">
                <p>BeginCar, &copy 2019 All rights reserved </p>
			</div>
		</div>
	</div>
<!-- //footer -->

</body>
</html>