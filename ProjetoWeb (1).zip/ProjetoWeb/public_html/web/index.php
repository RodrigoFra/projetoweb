<?php
session_start();
require('config.php');

if(!isset($_SESSION['maillog'])){
    
    header('location:/index.php');
}

    $sql_ativo=sprintf("select * from ativar;");
    $querry=mysqli_query($ligacao,$sql_ativo);
    $reg_ativo=mysqli_fetch_array($querry);

if($reg_ativo['ativo']==1 and $_SESSION['maillog']==0 and $_SESSION['nivel']!=3){
    header('location:/manutencao.php');
}

if(isset($_POST['procura'])){
    $sql_procura="select * from produtos where nome_prod like '%".$_POST['procura']."%';";
    $res_procura=mysqli_query($ligacao,$sql_procura);
}

    $sql_lista=sprintf("select * from produtos where tipo_peca='Alternador';");
    $res_lista=mysqli_query($ligacao,$sql_lista);
?>

<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Begin Car - Store</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Classic Style Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script src="js/jquery.min.js"></script>
<!-- //js -->
<!-- cart -->
<script src="js/simpleCart.min.js"></script>
<!-- cart -->
<!-- for bootstrap working -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<!-- animation-effect -->
<link href="css/animate.min.css" rel="stylesheet"> 
<script src="js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->
<link href='//fonts.googleapis.com/css?family=Cabin:400,500,600,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,300,700,900' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
	
<style>
    tab { padding-right: 8em; }  
    tab1 { padding-right: 1em; } 
    
    .arrow {
      border: solid black;
      border-width: 0 3px 3px 0;
      display: inline-block;
      padding: 3px;
    }

    .right {
      transform: rotate(-45deg);
      -webkit-transform: rotate(-45deg);
    }
    
   .cart_div span {
        font-size: 13px;
        line-height: 6px;
        padding: 1px;
        position: absolute;
        top: 10px;
        color: #fff;
        width: 9px;
        height: 16px;
        text-align: center;
    }
    
    .search-box{
        position: absolute;
        margin-top: 25px;
        top: 50%;
        left: 50%;
        transform: translate(-100%,-50%);
        background: #2f2f2f;
        height: 40px;
        border-radius: 50px;
        padding: 10px;
    }
    
    .search-box:hover > .search-txt{
        width: 240px;
        padding: 0 6px;
        margin-top: -3%;
    }
    
    .search-box:hover > .search-btn{
        background: white;
        margin-top: -9%;
    }
    
    .search-txt{
        border: none;
        background: none;
        outline: none;
        float: left;
        padding: 0;
        color: white;
        font-size: 16px;
        transition: 0.4s;
        line-height: 40px;
        width: 0px;
    }
    
    .search-btn{
        color: white;
        float: right;
        width: 0px;
        height: 0px;
        border-radius: 50%;
        background: white;
        display: flex;
        justify-content: center;
        align-items: center;
        transition: 0.4s;
    }
    
    .clean{
        padding: 0;
        border: none;
        background: none;
    }
</style>    
    
<body>
<!-- header -->
	<div class="header">
        <div class="header-grid-1">
            <div class="container">
				<div class="header-left animated wow fadeInLeft" data-wow-delay=".5s">
					<ul>
					    <li><i class="glyphicon glyphicon-headphones"></i>Apoio ao cliente 24/7</li>
						<li><i class="glyphicon glyphicon-envelope" ></i><a href="mailto:info@begincar.com">info@begincar.com</a></li>
						<li><i class="glyphicon glyphicon-earphone" ></i>261 338 465</li>
						
					</ul>
				</div>
				<div class="header-right animated wow fadeInRight" data-wow-delay=".5s">
				    <div class="header-right1">
				        <ul><tab></tab>
				            <li><i class="glyphicon glyphicon-user" ></i><a href="login.php">Conta</a></li>
                                <div class="header-right2">
                                    <a href="checkout.php">
                                        <p><img src="images/cart.png" /></p>
                                    </a>
                                        <div class="cart_div"><tab1></tab1>
                                    <a href="checkout.php">        
                                            <span>
                                               <?php
                                                    require('soma-carrinho.php');
                                                ?>
                                            </span>
                                    </a>
                                        </div>
                                </div>
					   </ul>
				    </div>
                 <div class="clearfix"> </div>
				</div>
                 <div class="clearfix"> </div>
			</div>
        </div>
			<div class="container">
			<div class="logo-nav">
				
					<nav class="navbar navbar-default">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header nav_2">
						<button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						 <div class="navbar-brand logo-nav-left ">
							<h1 class="animated wow pulse" data-wow-delay=".5s"><a href="index.php">Begin<span>Car</span></a></h1>
						</div>

					</div> 
					<div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
						<ul class="nav navbar-nav">
							<!-- Mega Menu -->
                             <?php
                                        while($reg_lista=mysqli_fetch_array($res_lista)){
                                            if($reg_lista['ver']==0){
                             ?>
							<li class="dropdown">
								<a href="" class="dropdown-toggle" data-toggle="dropdown">Peças Auto <b class="caret"></b></a>
								<ul class="dropdown-menu multi">
									<div class="row">
										<div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<h6>Sistema de Travagem</h6>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Pastilhas de travão</button></li>
                                                <input type="hidden" value="Pastilhas de travão" name="categ">
                                                </form>
												<form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Discos de Travão</button></li>
                                                <input type="hidden" value="Discos de travão" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Pinça de travão</button></li>
                                                <input type="hidden" value="Pinça de travão" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Jogo de travões</button></li>
                                                <input type="hidden" value="Jogo de travões" name="categ">
                                                </form>
											</ul>
										</div>
                                        <div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<h6>Filtros</h6>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Filtro de ar</button></li>
                                                <input type="hidden" value="Filtro de ar" name="categ">
                                                </form>
												<form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Filtro de óleo</button></li>
                                                <input type="hidden" value="Filtro de óleo" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Filtro de combustível</button></li>
                                                <input type="hidden" value="Filtro de combustível" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Filtro de habitáculo</button></li>
                                                <input type="hidden" value="Filtro de habitáculo" name="categ">
                                                </form>
											</ul>
										</div>
										<div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<h6>Suspensão & direção</h6>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Amortecedores</button></li>
                                                <input type="hidden" value="Amortecedores" name="categ">
                                                </form>
												<form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Barra Estabilizadora</button></li>
                                                <input type="hidden" value="Barra Estabilizadora" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Braço de suspensão</button></li>
                                                <input type="hidden" value="Braço de suspensão" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Rotula de direção</button></li>
                                                <input type="hidden" value="Rotula de direção" name="categ">
                                                </form>
											</ul><br><br>
										</div>
                                        <div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<h6>Embraiagem/Transmissão</h6>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Kit de embraiagem</button></li>
                                                <input type="hidden" value="Kit de embraiagem" name="categ">
                                                </form>
												<form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Veio de transmissão</button></li>
                                                <input type="hidden" value="Veio de transmissão" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Caixa de velocidades</button></li>
                                                <input type="hidden" value="Caixa de velocidades" name="categ">
                                                </form>
											</ul>
										</div>
                                        <div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<h6>Distribuição</h6>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Velas</button></li>
                                                <input type="hidden" value="Velas" name="categ">
                                                </form>
												<form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Kit de distribuição</button></li>
                                                <input type="hidden" value="Kit de distribuição" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Correia de distribuição</button></li>
                                                <input type="hidden" value="Correia de distribuição" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Bobina de ignição</button></li>
                                                <input type="hidden" value="Bobina de ignição" name="categ">
                                                </form>
											</ul>
										</div>
                                        <div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<h6>Outras peças</h6>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Elevador do vidro</button></li>
                                                <input type="hidden" value="Elevador do vidro" name="categ">
                                                </form>
												<form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Alternador</button></li>
                                                <input type="hidden" value="Alternador" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Amortecedores da Mala</button></li>
                                                <input type="hidden" value="Braço de suspensão" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Iluminação / Sinalização</button></li>
                                                <input type="hidden" value="Rotula de direção" name="categ">
                                                </form>
											</ul>
										</div>
        
										<div class="clearfix"></div>
									</div>
									
								</ul>
							</li>
                            <?php 
                                            }
                                        }
                            ?>
                            <li><a>
                                <form method="post" action="loja_products.php">
                                    <button class="clean" type="submit">Pneus</button>
                                    <input type="hidden" value="Pneus" name="categ">
                                </form>
                            </a></li>
							<li><a href="contact.php">Contacto</a></li>
						</ul>
					</div>
					</nav>
				</div>
		</div>
    </div>
<!-- //header -->


<!-- banner -->
	<div class="banner">
	
	
	<div class="banner-right">
					<ul id="flexiselDemo2">			
					<li><div class="banner-grid">
						<h2>Parcerias</h2>
							<div class="wome">
								<img class="img-responsive" src="images/logo1.jpg" alt="" style="width: 100%"/>
								</div>						
							</div></li>
						<li><div class="banner-grid">
						<h2>Parcerias</h2>
						<div class="wome">
								<img class="img-responsive" src="images/logo2.jpg" alt="" />						
								</div>						
							</div></li>
						<li><div class="banner-grid">
						<h2>Parcerias</h2>
						<div class="wome">
								<img class="img-responsive" src="images/logo3.jpg" alt="" />			
								</div>						
							</div></li>
                        <li><div class="banner-grid">
						<h2>Parcerias</h2>
						<div class="wome">
								<img class="img-responsive" src="images/logo4.jpg" alt="" />			
								</div>						
							</div></li>
                        <li><div class="banner-grid">
						<h2>Parcerias</h2>
						<div class="wome">
								<img class="img-responsive" src="images/logo5.jpg" alt="" />			
								</div>						
							</div></li>
                        <li><div class="banner-grid">
						<h2>Parcerias</h2>
						<div class="wome">
								<img class="img-responsive" src="images/logo6.jpg" alt="" />			
								</div>						
							</div></li>
                        <li><div class="banner-grid">
						<h2>Parcerias</h2>
						<div class="wome">
                            <img class="img-responsive" src="images/logo7.jpg" alt="" style="width: 200px"/>		
								</div>						
							</div></li>
                        <li><div class="banner-grid">
						<h2>Parcerias</h2>
						<div class="wome">
								<img class="img-responsive" src="images/logo8.jpg" alt="" />			
								</div>						
							</div></li>
                        <li><div class="banner-grid">
						<h2>Parcerias</h2>
						<div class="wome">
								<img class="img-responsive" src="images/logo9.jpg" alt="" />			
								</div>						
							</div></li>
					</ul>
<script type="text/javascript">
    $(window).load(function() {
        $("#flexiselDemo2").flexisel({
            visibleItems: 1,
            animationSpeed: 1000,
            autoPlay: true,
            autoPlaySpeed: 5000,    		
            pauseOnHover: true,
            enableResponsiveBreakpoints: true,
            responsiveBreakpoints: { 
                portrait: { 
                    changePoint:480,
                    visibleItems: 1
                }, 
                landscape: { 
                    changePoint:640,
                    visibleItems: 1
                },
                tablet: { 
                    changePoint:768,
                    visibleItems: 1
                }
            }
        });

    });
</script>
        
		<script type="text/javascript" src="js/jquery.flexisel.js"></script>
		<script type="text/javascript" src="funcao.js"></script>

    </div>

        </div>

<!-- //banner -->
<!--content-->
			     <div class="content-top">
					
					<div class="col-md-7 col-md2 animated wow fadeInLeft" data-wow-delay=".1s">
						<div class="col-sm-4 item-grid simpleCart_shelfItem">
							<div class="grid-pro">
								<div  class=" grid-product " >
									<figure>		
										<a>
											<div class="grid-img">
												<img  src="images/travagem.png" class="img-responsive" alt="">
											</div>
											<div class="grid-img">
												<img  src="images/travagem.png" class="img-responsive"  alt="">
											</div>			
										</a>		
									</figure>	
								</div>
								<div class="women">
                                    <h4><b>Sistema de Travagem</b></h4><br>
									<h5 align="left" style="font-size:16px;">&#8250; Pastilhas de travão</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Discos de travão</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Pinça de travão</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Jogo de travões</h5>
								</div>
							</div>
						</div>
				
						<div class="col-sm-4 item-grid simpleCart_shelfItem">
							<div class="grid-pro">
								<div  class=" grid-product " >
									<figure>		
										<a>
											<div class="grid-img">
												<img  src="images/filtros.jpg" class="img-responsive" alt="">
											</div>
											<div class="grid-img">
												<img  src="images/filtros.jpg" class="img-responsive"  alt="">
											</div>			
										</a>		
									</figure>	
								</div>
								<div class="women">
                                    <h4><b>Filtros</b></h4><br>
									<h5 align="left" style="font-size:16px;">&#8250; Filtro de ar</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Filtro de óleo</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Filtro de combustivel</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Filtro de habitáculo</h5>
								</div>
							</div>
						</div>
                        
						<div class="col-sm-4 item-grid simpleCart_shelfItem">
							<div class="grid-pro">
								<div  class=" grid-product " >
									<figure>		
										<a>
											<div class="grid-img">
												<img  src="images/suspensao.jpg" class="img-responsive" alt="">
											</div>
											<div class="grid-img">
												<img  src="images/direcao.jpg" class="img-responsive"  alt="">
											</div>			
										</a>		
									</figure>	
								</div>
								<div class="women">
                                    <h4><b>Suspensão & Direção</b></h4><br>
									<h5 align="left" style="font-size:16px;">&#8250; Amortecedores</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Barra Estabilizadora</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Braço de suspensão</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Rotula de direção</h5>
								</div>
							</div>
						</div>
                        
					<div class="clearfix"></div>
                        
					</div>
					<div class="col-md-5 col-md1 animated wow fadeInRight" data-wow-delay=".1s">
						<div class="col-3">
							<img src="images/renault.jpg" class="img-responsive " alt="">
							<div class="col-pic">
								<h5> Melhor qualidade</h5>
								<p>As peças são testadas e aprovadas</p>
							</div>
						</div>
						
					</div>
					<div class="clearfix"></div>
				</div>
    
				<div class="content-top">
					<div class="col-md-5 col-md1 animated wow fadeInLeft" data-wow-delay=".1s">
						<div class="col-3">
							<img src="images/bmw2.jpg" class="img-responsive " alt="">
							<div class="col-pic">	
								<h5> Maior conforto</h5> 
								<p>Bancos com estofos em tecido e pele</p>
                            </div>
						</div>
						
					</div>
					<div class="col-md-7 col-md2 animated wow fadeInRight" data-wow-delay=".1s">
						<div class="col-sm-4 item-grid simpleCart_shelfItem">
							<div class="grid-pro">
								<div  class=" grid-product " >
									<figure>		
										<a>
											<div class="grid-img">
												<img  src="images/transmissao.jpg" class="img-responsive" alt="">
											</div>
											<div class="grid-img">
												<img  src="images/embraiagem.jpg" class="img-responsive"  alt="">
											</div>			
										</a>		
									</figure>	
								</div>
								<div class="women">
                                    <h4><b>Embraiagem/Transmissão</b></h4><br>
									<h5 align="left" style="font-size:16px;">&#8250; Kit de embraiagem</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Veio de transmissão</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Caixa de velocidades</h5><br><br>
								</div>
							</div>
						</div>
				
						<div class="col-sm-4 item-grid simpleCart_shelfItem">
							<div class="grid-pro">
								<div  class=" grid-product " >
									<figure>		
										<a>
											<div class="grid-img">
												<img  src="images/velas.jpg" class="img-responsive" alt="">
											</div>
											<div class="grid-img">
												<img  src="images/correias.jpg" class="img-responsive"  alt="">
											</div>			
										</a>		
									</figure>	
								</div>
								<div class="women">
                                    <h4><b>Distribuição</b></h4><br>
                                    <h5 align="left" style="font-size:16px;">&#8250; Velas</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Kit de distribuição</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Correia de distribuição</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Bobina de ignição</h5>
								</div>
							</div>
						</div>
                        
						<div class="col-sm-4 item-grid simpleCart_shelfItem">
							<div class="grid-pro">
								<div  class=" grid-product " >
									<figure>		
										<a>
											<div class="grid-img">
												<img  src="images/arrefecimento.jpg" class="img-responsive" alt="">
											</div>
											<div class="grid-img">
												<img  src="images/arrefecimento.jpg" class="img-responsive"  alt="">
											</div>			
										</a>		
									</figure>	
								</div>
								<div class="women">
                                    <h4><b>Arrefecimento do motor</b></h4><br>
									<h5 align="left" style="font-size:16px;">&#8250; Radiador</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Intercooler</h5><br>
                                    <h5 align="left" style="font-size:16px;">&#8250; Ventilador de radiador</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Termóstato</h5>
								</div>
							</div>
						</div>
					<div class="clearfix"></div>
					</div>
					<div class="clearfix"></div>
                </div>
                
                 <div class="content-top">
					<div class="col-md-7 col-md2 animated wow fadeInLeft" data-wow-delay=".1s">
						<div class="col-sm-4 item-grid simpleCart_shelfItem">
							<div class="grid-pro">
								<div  class=" grid-product " >
									<figure>		
										<a>
											<div class="grid-img">
												<img  src="images/escape.jpg" class="img-responsive" alt="">
											</div>
											<div class="grid-img">
												<img  src="images/escape.jpg" class="img-responsive"  alt="">
											</div>			
										</a>		
									</figure>	
								</div>
								<div class="women">
                                    <h4><b>Sistema de Escape</b></h4><br>
									<h5 align="left" style="font-size:16px;">&#8250; Tubos de escape</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Panelas de escape</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Catalisador</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Filtro de partículas</h5>
								</div>
							</div>
						</div>
				
						<div class="col-sm-4 item-grid simpleCart_shelfItem">
							<div class="grid-pro">
								<div  class=" grid-product " >
									<figure>		
										<a>
											<div class="grid-img">
												<img  src="images/eletrica.jpg" class="img-responsive" alt="">
											</div>
											<div class="grid-img">
												<img  src="images/eletrica.jpg" class="img-responsive"  alt="">
											</div>			
										</a>		
									</figure>	
								</div>
								<div class="women">
                                    <h4><b>Sistema eléctrico</b></h4><br>
									<h5 align="left" style="font-size:16px;">&#8250; Alternadores</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Baterias</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Fusíveis</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Motor de arranque</h5>
								</div>
							</div>
						</div>
                        
						<div class="col-sm-4 item-grid simpleCart_shelfItem">
							<div class="grid-pro">
								<div  class=" grid-product " >
									<figure>		
										<a>
											<div class="grid-img">
												<img  src="images/oleo.jpg" class="img-responsive" alt="">
											</div>
											<div class="grid-img">
												<img  src="images/oleo.jpg" class="img-responsive"  alt="">
											</div>			
										</a>		
									</figure>	
								</div>
								<div class="women">
                                    <h4><b>Óleos e fluidos</b></h4><br>
									<h5 align="left" style="font-size:16px;">&#8250; Óleo do motor</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Óleo da caixa automática</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Anticongelante</h5><br>
									<h5 align="left" style="font-size:16px;">&#8250; Líquido dos travões</h5>
								</div>
							</div>
						</div>
					<div class="clearfix"></div>
					</div>
					<div class="col-md-5 col-md1 animated wow fadeInRight" data-wow-delay=".1s">
						<div class="col-3">
							<a href="single.php"><img src="images/volks.jpg" class="img-responsive " alt="">
							<div class="col-pic">
								<h5> Confiança</h5>
								<p>Temos confiança nos fornecedores e produtos vendidos</p>
							</div></a>
						</div>
                     </div>
                        <div class="clearfix"></div>
                </div>
				<!----->

<!-- footer -->
	<div class="footer">
		<div class="container">
		<div class="footer-top">
		<div class="clearfix"> </div>
		</div>
			<div class="footer-grids">
				<div class="col-md-4 footer-grid animated wow fadeInLeft" data-wow-delay=".5s">
					<h3>Sobre Nós</h3>
					<p>A Begin Car é uma empresa que comercializa todo o tipo de peças automóveis para todo o tipo de veículos ligeiros.<span>Com o melhor preço, qualidade e serviço do mercado.</span></p>
				</div>
				<div class="col-md-4 footer-grid animated wow fadeInLeft" data-wow-delay=".6s">
					<h3>Os nossos contactos</h3>
					<ul>
						<li><i class="glyphicon glyphicon-map-marker" ></i>Rua Doutor Alberto Martins Santos, <span>2540-087 Bombarral, PT</span></li>
						<li class="foot-mid"><i class="glyphicon glyphicon-envelope" ></i><a href="mailto:info@begincar.com">info@begincar.com</a></li>
						<li><i class="glyphicon glyphicon-earphone" ></i>261 338 465</li>
					</ul>
				</div>
				<div class="col-md-4 footer-grid animated wow fadeInLeft" data-wow-delay=".7s">
				<h3>Deseja receber novidades? </h3>
				<form method=post>
					<input type="text" placeholder="Email"  required="required">
					<input type="submit" value="Enviar">
				</form>
				</div>
                <div class="col-md-2 footer-top2">
		              <a href="contact.php">Contacte-nos</a>
		         </div>
			
				<div class="clearfix"> </div>
			</div>
			
			<div class="copy-right animated wow fadeInUp" data-wow-delay=".5s">
                <p>BeginCar, &copy 2019 All rights reserved </p>
			</div>
		</div>
	</div>
<!-- //footer -->
    
</body>
</html>