<?php
session_start();
require('config.php');

    $sql_ativo=sprintf("select * from ativar;");
    $querry=mysqli_query($ligacao,$sql_ativo);
    $reg_ativo=mysqli_fetch_array($querry);

if($reg_ativo['ativo']==1 and $_SESSION['nivel']!=3){
    header('location:/manutencao.php');
}

if(isset($_GET['id'])){
     $sql=sprintf("delete from loja_detalhes where id=%d",$_GET['id']);
     mysqli_query($ligacao,$sql);
    header("location:checkout.php");
}

if(isset($_POST['quant'])){
    $sql_quantidade=sprintf("update loja_detalhes set quant=%d where id=%d;",$_POST['quant'],$_POST['id']);
    $res_quant=mysqli_query($ligacao, $sql_quantidade);
    header("location:checkout.php");
}

    $sql_lista=sprintf("select * from loja_detalhes where mail='%s' and estado=1;",$_SESSION['maillog']);
    $res_lista=mysqli_query($ligacao,$sql_lista);
?>

<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Begin Car - Carrinho</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Classic Style Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script src="js/jquery.min.js"></script>
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
<!-- //js -->
<!-- cart -->
<script src="js/simpleCart.min.js"></script>
<!-- cart -->
<!-- for bootstrap working -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<!-- animation-effect -->
<link href="css/animate.min.css" rel="stylesheet"> 
<script src="js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->
<link href='//fonts.googleapis.com/css?family=Cabin:400,500,600,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,300,700,900' rel='stylesheet' type='text/css'></head>
    
<style>
    tab { padding-right: 8em; }  
    tab1 { padding-right: 1em; } 
    
    .cart_div span {
        font-size: 13px;
        line-height: 6px;
        padding: 1px;
        position: absolute;
        top: 10px;
        color: #fff;
        width: 9px;
        height: 16px;
        text-align: center;
    }
</style>   
	
<body>
<!-- header -->
	<div class="header">
        <div class="header-grid-1">
            <div class="container">
				<div class="header-left animated wow fadeInLeft" data-wow-delay=".5s">
					<ul>
					    <li><i class="glyphicon glyphicon-headphones"></i>Apoio ao cliente 24/7</li>
						<li><i class="glyphicon glyphicon-envelope" ></i><a href="mailto:info@begincar.com">info@begincar.com</a></li>
						<li><i class="glyphicon glyphicon-earphone" ></i>261 338 465</li>
						
					</ul>
				</div>
				<div class="header-right animated wow fadeInRight" data-wow-delay=".5s">
				    <div class="header-right1">
				        <ul><tab></tab>
				            <li><i class="glyphicon glyphicon-user" ></i><a href="login.php">Conta</a></li>
                                <div class="header-right2">
                                    <p><img src="images/cart.png" /></p>
                                        <div class="cart_div"><tab1></tab1>
                                            <span>
                                               <?php
                                                    require('soma-carrinho.php');
                                                ?>
                                            </span>
                                        </div>
                                </div>
					   </ul>
				    </div>
                 <div class="clearfix"> </div>
				</div>
                 <div class="clearfix"> </div>
			</div>
        </div>
    </div>
<!-- //header -->
<!--banner-->
<div class="banner-top">
	<div class="container">
		<h2 class="animated wow fadeInLeft" data-wow-delay=".5s">Carrinho</h2>
		<h3 class="animated wow fadeInRight" data-wow-delay=".5s"><a href="index.php">Inicio</a><label>/</label>Carrinho</h3>
		<div class="clearfix"> </div>
	</div>
</div>
<!-- contact -->
		<div class="check-out">	 
		<div class="container">	 
	 
				<script>$(document).ready(function(c) {
					$('.close1').on('click', function(c){
						$('.cross').fadeOut('slow', function(c){
							$('.cross').remove();
						});
						});	  
					});
			   </script>
			<script>$(document).ready(function(c) {
					$('.close2').on('click', function(c){
						$('.cross1').fadeOut('slow', function(c){
							$('.cross1').remove();
						});
						});	  
					});
			   </script>	
			   <script>$(document).ready(function(c) {
					$('.close3').on('click', function(c){
						$('.cross2').fadeOut('slow', function(c){
							$('.cross2').remove();
						});
						});	  
					});
			   </script>
            
            <?php 
                if($soma_carrinho==0){
            ?>
            
    <table class="table animated wow fadeInLeft" data-wow-delay=".5s">
		  <tr>
			<th class="t-head">Imagem</th>
			<th class="t-head">Nome</th>
			<th class="t-head">Preço</th>
			<th class="t-head">Quantidade</th>
			<th class="t-head">Total</th>
			<th class="t-head">Remover</th> 
		  </tr>
            <?php
                $sub_total=0;
                $iva=0;
                $preco_final=0;
     
                while($reg_lista=mysqli_fetch_array($res_lista)){
                    $preco_quant=$reg_lista['quant']*$reg_lista['preco_produto'];
                    $sub_total+=$preco_quant;
                    $portes=10;
                    $iva=$sub_total * 0.23; 
                    $preco_final=$sub_total + $portes + $iva;         
            ?>
		  <tr class="cross">
			<td class="t-data">
				<img src="<?php echo $reg_lista['ficheiro']; ?>" class="img-resp" alt="">
            </td>
			<div class="sed">
                <td class="t-data">
				    <h5><?php echo $reg_lista['nome_produto'] ?></h5>
                </td>
			</div>
				<div class="clearfix"> </div>
			<td class="t-data"><?php echo number_format($reg_lista['preco_produto'],2); ?>€</td>
			<td class="t-data">
                <div class="quantity-box">           
                     <form method="post">
                        <input type="number" name="quant" value="<?php echo $reg_lista['quant']; ?>" min="0" step="1" class="c-input-text qty text">
                        <input type="hidden" name="id" value="<?php echo $reg_lista['id']; ?>">
                    </form>
                </div>
			</td>
			<td class="t-data"><?php echo $preco_quant ;?>€</td>
            <td class="t-data">
                <a href="checkout.php?id=<?php echo $reg_lista['id']; ?>" style="color:#222222;">
                    <i class='far fa-times-circle'></i>
                </a>
            </td>
		  </tr>
            <?php
                    }
                
            ?>
	</table>
        <br><br><br>
        <?php
                }else{
            ?>
            
            
 <table class="table animated wow fadeInLeft" data-wow-delay=".5s">
		  <tr>
			<th class="t-head">Imagem</th>
			<th class="t-head">Nome</th>
			<th class="t-head">Preço</th>
			<th class="t-head">Quantidade</th>
			<th class="t-head">Total</th>
			<th class="t-head">Remover</th> 
		  </tr>
            <?php
                $sub_total=0;
                $iva=0;
                $preco_final=0;
     
                while($reg_lista=mysqli_fetch_array($res_lista)){
                    $preco_quant=$reg_lista['quant']*$reg_lista['preco_produto'];
                    $sub_total+=$preco_quant;
                    $iva=$sub_total * 0.23; 
                    $preco_final=$sub_total + $iva;         
            ?>
		  <tr class="cross">
			<td class="t-data">
				<img src="<?php echo $reg_lista['ficheiro']; ?>" class="img-resp" alt="">
            </td>
			<div class="sed">
                <td class="t-data">
				    <h5><?php echo $reg_lista['nome_produto'] ?></h5>
                </td>
			</div>
				<div class="clearfix"> </div>
			<td class="t-data"><?php echo number_format($reg_lista['preco_produto'],2); ?>€</td>
			<td class="t-data">
                <div class="quantity-box">           
                     <form method="post">
                        <input type="number" name="quant" value="<?php echo $reg_lista['quant']; ?>" min="0" step="1" class="c-input-text qty text">
                        <input type="hidden" name="id" value="<?php echo $reg_lista['id']; ?>">
                    </form>
                </div>
			</td>
			<td class="t-data"><?php echo number_format($preco_quant,2); ?>€</td>
            <td class="t-data">
                <a href="checkout.php?id=<?php echo $reg_lista['id']; ?>" style="color:#222222;">
                    <img src="images/cruz.png" width="25px">
                </a>
            </td>
		  </tr>
            <?php
                }
            ?>
	</table>
				<div class=" cart-total">
			
			 <h5 class="continue" >Fatura da encomenda</h5>
			 <div class="price-details">
                 <h3>Detalhes</h3>
				 <span>Total em peças</span>
				 <span class="total1"><?php echo number_format($sub_total,2); ?>€</span>
				 <span>Portes</span>
				 <span class="total1">-----&nbsp;€</span>
				 <span>Iva</span>
				 <span class="total1"><?php echo number_format($iva,2) ;?>€</span>
				 <div class="clearfix"></div>				 
			 </div>	
			 <ul class="total_price">
			   <li class="last_price"> <h4>TOTAL</h4></li>	
			   <li class="last_price"><span><?php echo number_format($preco_final,2) ;?>€</span></li>
			   <div class="clearfix"> </div>
			 </ul>
			
			 <a href="pagamento.php">Finalizar Compra</a>
			 
			</div>
		
            <?php
                }
            ?>
		 </div>
		 </div>
		 				<!--quantity-->
			<script>
			$('.value-plus').on('click', function(){
				var divUpd = $(this).parent().find('.value'), newVal = parseInt(divUpd.text(), 10)+1;
				divUpd.text(newVal);
			});

			$('.value-minus').on('click', function(){
				var divUpd = $(this).parent().find('.value'), newVal = parseInt(divUpd.text(), 10)-1;
				if(newVal>=1) divUpd.text(newVal);
			});
			</script>
			<!--quantity-->
    <div class="clearfix"> </div>
    <br>
    
<!-- footer -->
	<div class="footer">
		<div class="container">
		<div class="footer-top">
		<div class="clearfix"> </div>
		</div>
			<div class="footer-grids">
				<div class="col-md-4 footer-grid animated wow fadeInLeft" data-wow-delay=".5s">
					<h3>Sobre Nós</h3>
					<p>A Begin Car é uma empresa que comercializa todo o tipo de peças automóveis para todo o tipo de veículos ligeiros.<span>Com o melhor preço, qualidade e serviço do mercado.</span></p>
				</div>
				<div class="col-md-4 footer-grid animated wow fadeInLeft" data-wow-delay=".6s">
					<h3>Os nossos contactos</h3>
					<ul>
						<li><i class="glyphicon glyphicon-map-marker" ></i>Rua Doutor Alberto Martins Santos, <span>2540-087 Bombarral, PT</span></li>
						<li class="foot-mid"><i class="glyphicon glyphicon-envelope" ></i><a href="mailto:info@begincar.com">info@begincar.com</a></li>
						<li><i class="glyphicon glyphicon-earphone" ></i>261 338 465</li>
					</ul>
				</div>
				<div class="col-md-4 footer-grid animated wow fadeInLeft" data-wow-delay=".7s">
				<h3>Deseja receber novidades? </h3>
				<form method=post>
					<input type="text" placeholder="Email"  required="required">
					<input type="submit" value="Enviar">
				</form>
				</div>
                <div class="col-md-2 footer-top2">
		              <a href="contact.php">Contacte-nos</a>
		         </div>
			
				<div class="clearfix"> </div>
			</div>
			
			<div class="copy-right animated wow fadeInUp" data-wow-delay=".5s">
                <p>BeginCar, &copy 2019 All rights reserved </p>
			</div>
		</div>
	</div>
<!-- //footer -->

</body>
</html>