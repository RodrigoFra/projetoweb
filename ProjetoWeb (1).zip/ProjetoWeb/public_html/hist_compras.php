<?php

session_start();
require("config.php");

if(isset($_POST['back1'])){
    
    header('location:../public_html/web/login_util.php');
}

if(isset($_GET['enviar'])){
    $erros='';
    if($_GET['ano_vendas']==''){
        $erros.='Precisa de colocar um ano!!<br>';
    }
    if($erros==''){
        if($_GET['mes_vendas']=='Janeiro'){
            $mes=1;
        }
        if($_GET['mes_vendas']=='Fevereiro'){
            $mes=2;
        }
        if($_GET['mes_vendas']=='Março'){
            $mes=3;
        }
        if($_GET['mes_vendas']=='Abril'){
            $mes=4;
        }
        if($_GET['mes_vendas']=='Maio'){
            $mes=5;
        }
        if($_GET['mes_vendas']=='Junho'){
            $mes=6;
        }
        if($_GET['mes_vendas']=='Julho'){
            $mes=7;
        }
        if($_GET['mes_vendas']=='Agosto'){
            $mes=8;
        }
        if($_GET['mes_vendas']=='Setembro'){
            $mes=9;
        }
        if($_GET['mes_vendas']=='Outubro'){
            $mes=10;
        }
        if($_GET['mes_vendas']=='Novembro'){
            $mes=11;
        }
        if($_GET['mes_vendas']=='Dezembro'){
            $mes=12;
        }
        if($_GET['mes_vendas']!=''){
            $data1=$_GET['ano_vendas'].'-'.$mes.'-01';
            if($mes==12){
                $_GET['ano_vendas']++;
                $mes=1;
            } else {
                $mes++;
            }
            $data2=$_GET['ano_vendas'].'-'.$mes.'-01';
        } else {
            $data1=$_GET['ano_vendas'].'-01-01';
            $_GET['ano_vendas']++;
            $data2=$_GET['ano_vendas'].'-01-01';
        }
    }
}
$data=date("y");

if(!isset($data1)){
    $data1='20'.$data.'-01-01';
}
if(!isset($data2)){
    $data++;
    $data2='20'.$data.'-01-01';
}

$sql_lista=sprintf("SELECT * FROM loja_pagamento WHERE data_venda >= '%s' and data_venda < '%s' and  mail='%s';" ,$data1,$data2, $_SESSION['maillog']);
$res_lista=mysqli_query($ligacao,$sql_lista);
   
?>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Landing PAGE Html5 Template">
    <meta name="keywords" content="landing,startup,flat">
    <meta name="author" content="Made By GN DESIGNS">

    <title>Begin Car - Vortex layout</title>

    <!-- // PLUGINS (css files) // -->
    <link href="assets/js/plugins/bootsnav_files/skins/color.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/animate.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/bootsnav.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/overwrite.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.theme.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.transitions.css" rel="stylesheet">
    <link href="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/magnific-popup.css" rel="stylesheet">
    <!--// ICONS //-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--// BOOTSTRAP & Main //-->
    <link href="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/main.css" rel="stylesheet">
</head>

<body>

    <!--======================================== 
           Preloader
    ========================================-->
    <div class="page-preloader">
        <div class="spinner">
            <div class="rect1"></div>
            <div class="rect2"></div>
            <div class="rect3"></div>
            <div class="rect4"></div>
            <div class="rect5"></div>
        </div>
    </div>
      <!--======================================== 
           Header
    ========================================-->

    <!--//** Navigation**//-->
    <nav  data-minus-value-desktop="70" data-minus-value-mobile="55" data-speed="1000">

        <div class="container">
            <!-- Start Header Navigation -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                    <i class="fa fa-bars"></i>
                </button>
            </div>
        </div>
    </nav>
            <!-- End Header Navigation -->

 
    <style>
        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            margin-left: auto;
            margin-right: auto;
        }
         
        td,th {
            border: 1px solid #44c5ee;
            text-align: left;
            padding: 8px;
        }
         
        h1 {
            color: #44c5ee;
        }
        
        .form-control1 {
            display: block;
            width: 100%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;
            -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
            box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
            -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
            -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
            transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
        }
    </style>
    
    <center>
        <h2>Produtos Vendidos (p/ Mês e Ano)</h2>
        <hr>
        <?php
            if(isset($_GET['enviar'])){
                if($erros!=''){
        ?><div class="alert alert-danger" align="center"><?php echo $erros ; ?></div><?php
                }
            }
        ?>
            <div class="row" style="margin-left: 615px;">
                <form method="get">
                    <div class="col-sm-2">
                        <label>Ano:</label>
                            <select class="form-control1" name="ano_vendas">
                                <option></option>
                                <option>2021</option>
                                <option>2022</option>
                                <option>2023</option>
                                <option>2024</option>
                                <option>2025</option>
                                <option>2026</option>
                                <option>2027</option>
                                <option>2028</option>
                                <option>2029</option>
                                <option>2030</option>
                            </select>
                        </div>
                    <div class="col-sm-2">
                        <label>Mês:</label>
                            <select class="form-control1" name="mes_vendas">
                                <option></option>
                                <option>Janeiro</option>
                                <option>Fevereiro</option>
                                <option>Março</option>
                                <option>Abril</option>
                                <option>Maio</option>
                                <option>Junho</option>
                                <option>Julho</option>
                                <option>Agosto</option>
                                <option>Setembro</option>
                                <option>Outubro</option>
                                <option>Novembro</option>
                                <option>Dezembro</option>
                            </select>
                        </div>
                    <div class="col-sm-2" style="margin-top:20px;">
                        <input type="submit" class="btn btn-blue" name="enviar" value="Verificar">
                    </div>
                </form>
            </div>
        <br>
        <br>
        <table id="myTable">
            <tr>
                <th>ID da Venda</th>
                <th>Tipo de Pagamento</th>
                <th>E-mail</th>
                <th>Morada</th>
                <th>Cidade</th>
                <th>Data da Venda</th>
                <th>Detalhes</th>
            </tr>
            <tbody>
            <?php
                while($reg_lista=mysqli_fetch_array($res_lista)){
            ?>
                    <tr>
                        <td align="center"><?php echo $reg_lista['id_venda']; ?></td>
                        <td align="center"><?php echo $reg_lista['tipo_pagamento']; ?></td>
                        <td align="center"><?php echo $reg_lista['mail']; ?></td>
                        <td align="center"><?php echo $reg_lista['morada']; ?></td>
                        <td align="center"><?php echo $reg_lista['cidade']; ?></td>
                        <td align="center"><?php echo $reg_lista['data_venda']; ?></td>
                        <td>
                            <form method="post">
                                <button type="submit" name="detalhes" class="btn btn-blue" style="width: 100%;">Detalhes</button>
                                <input type="hidden" name="id" value="<?php echo $reg_lista['id_venda']; ?>">
                            </form>
                        </td>
                    </tr>
            <?php
                }
            ?>
            </tbody>
        </table>
    </center>
    
            <?php
                if(isset($_POST['detalhes'])){
                    $sql_venda=sprintf("select * from loja_detalhes where id_venda=%d;",$_POST['id']);
                    $res_venda=mysqli_query($ligacao,$sql_venda);
            ?>
    
    <center>
        <br>
        <br>
        <table id="myTable">
            <tr>
                <th>ID da Venda</th>
                <th>Nome do Produto</th>
                <th>Referência do Produto</th>
                <th>Imagem</th>
                <th>Quantidade</th>
                <th>Preço c/ Iva</th>
            </tr>
            <tbody>
            <?php
                        $sub_total=0;
                        $iva=0;
                        $preco_final=0;
                        $preco_total=0;
                
                        while($reg_venda=mysqli_fetch_array($res_venda)){
                            $sub_total=0;
                            $multiplicacao=$reg_venda['quant']*$reg_venda['preco_produto'];
                            $sub_total+=$multiplicacao;
                            $iva=$sub_total * 0.23; 
                            $preco_final=$sub_total + $iva;
                            $preco_total=$preco_total+$preco_final;
            ?>
                    <tr>
                        <td align="center"><?php echo $reg_venda['id_venda']; ?></td>
                        <td align="center"><?php echo $reg_venda['nome_produto']; ?></td>
                        <td align="center"><?php echo $reg_venda['ref']; ?></td>
                        <td align="center"><img src="<?php echo $reg_venda['ficheiro']; ?>" width="105px" height="95px" alt=""></td>
                        <td align="center"><?php echo $reg_venda['quant']; ?></td>
                        <td align="center"><?php echo number_format($preco_final,2); ?>€</td>
                    </tr>
                <?php
                        }
                ?>
            </tbody>
                <tr>
                    <th align="center" colspan="5">Preço Total:</th>
                    <td align="center"><?php echo number_format($preco_total,2); ?>€</td>
                </tr>
        </table>
    </center>
    
        <?php
                }
        ?>
    
        <script>
            function myFunction() {
              // Declare variables
              var input, filter, table, tr, td, i, txtValue;
              input = document.getElementById("myInput");
              filter = input.value.toUpperCase();
              table = document.getElementById("myTable");
              tr = table.getElementsByTagName("tr");

              // Loop through all table rows, and hide those who don't match the search query
              for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td")[1];
                if (td) {
                  txtValue = td.textContent || td.innerText;
                  if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                  } else {
                    tr[i].style.display = "none";
                  }
                }
              }
            }
        </script>
        
        <hr>
        <form class="contact-form" method="post">
                 <button type="submit" name="back1" class="btn btn-blue" style="width: 10%;">Voltar</button>
        </form>
    
 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
    <script src="assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>
    <script src="assets/js/plugins/bootsnav_files/js/bootsnav.js"></script>
    <script src="assets/js/plugins/typed.js-master/typed.js-master/dist/typed.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js"></script>
    <script src="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
    <script src="assets/js/main.js"></script>
    
    </body>
</html> 