<?php
$ligacao = mysqli_connect('localhost', 'id20210782_root', 'GYXCfA)6!CzZvz1pSTmn', 'id20210782_210100324');
if(!$ligacao){ //CONEXÃO À BASE DE DADOS
    echo 'ERRO DE LIGAÇÃO';
}

mysqli_set_charset($ligacao,'UTF8'); // DEFINE O CHARSET DO OUTPUT DE MYSQL
?>