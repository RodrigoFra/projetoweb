<?php
    require 'smtp/PHPMailerAutoload.php';
    require  'smtp/class.phpmailer.php' ;

    if(isset($_POST['assunto']) && !empty($_POST['assunto'])){
        $assunto = $_POST['assunto'];
    } 

    if(isset($_POST['mensagem']) && !empty($_POST['mensagem'])){
        $mensagem = $_POST['mensagem'];
    }

      if(isset($_POST['email']) && !empty($_POST['email'])){
        $email = $_POST['email'];
    }


    $mail = new PHPMailer; 



    $mail->isHTML(true);

    //$mail->SetFrom('ivogames2002@gmail.com', 'Destinatario');


    $mail->Subject = utf8_decode($assunto);
    $mail->Body = $mensagem;
    $mail->AltBody = strip_tags($mensagem);
    $mail->addAddress('aluno15021@damiaodegoes.pt', 'Remetente');
    $mail->SetFrom($email);

    if(!$mail->send()) {
        echo 'Não foi possivel enviar a mensagem. <br>'; 
        echo 'Erro: '.$mail->ErrorInfo;
    } else {
        echo 'MENSAGEM ENVIADA';
    }
?>