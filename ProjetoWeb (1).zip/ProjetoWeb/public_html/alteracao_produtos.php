<?php
session_start();
require("config.php");

    $sql_ativo=sprintf("select * from ativar;");
    $querry=mysqli_query($ligacao,$sql_ativo);
    $reg_ativo=mysqli_fetch_array($querry);

if($reg_ativo['ativo']==1 and $_SESSION['nivel']!=3){
    header('location:/manutencao.php');
}

$erros='';

if(isset($_POST['back1'])){
    
    header('location:produtos.php');
}

if(isset($_POST['verif'])){
    
    header('location:editar_produto.php');
}

if(isset($_POST['submeter'])){
    
        $target_dir = "ficheiros/";
        $novo_nome=md5($_FILES["ficheiro"]["name"].DATE('Y-m-d').date('H:i:s'));
        $novo_nome2=md5($_FILES["ficheiro2"]["name"].DATE('Y-m-d').date('H:i:s'));
        $novo_nome3=md5($_FILES["ficheiro3"]["name"].DATE('Y-m-d').date('H:i:s'));


        $uploadOk = 0;
        $imageFileType = strtolower(pathinfo($_FILES["ficheiro"]["name"],PATHINFO_EXTENSION));
        $imageFileType2 = strtolower(pathinfo($_FILES["ficheiro2"]["name"],PATHINFO_EXTENSION));
        $imageFileType3 = strtolower(pathinfo($_FILES["ficheiro3"]["name"],PATHINFO_EXTENSION));
    
        $target_file = $target_dir . $novo_nome . '.'.$imageFileType ;
        $target_file2 = $target_dir . $novo_nome2 . '.'.$imageFileType2 ;
        $target_file3 = $target_dir . $novo_nome3 . '.'.$imageFileType3 ;
    
        if (move_uploaded_file($_FILES["ficheiro"]["tmp_name"], $target_file)) {
            if ($_FILES["ficheiro"]["size"] < 900000) {

                $sql=sprintf("update produtos set  ficheiro='../%s' , nome_original='%s' where id=%d;",$target_file,$_FILES["ficheiro"]["name"],$_POST['id']);
                if(!mysqli_query($ligacao,$sql)){
                    $erros.='1º Ficheiro não foi enviado corretamente'; 
                }
            } else {
                $erros.= "Ficheiro ".$_FILES['ficheiro']["name"]." muito grande<br>";           
            }
        }
    
        if (move_uploaded_file($_FILES["ficheiro2"]["tmp_name"], $target_file2)) {
            if ($_FILES["ficheiro2"]["size"] < 900000) {

                $sql=sprintf("update produtos set  ficheiro2='../%s' , nome_original2='%s' where id=%d;",$target_file2,$_FILES["ficheiro2"]["name"],$_POST['id']);
                if(!mysqli_query($ligacao,$sql)){
                    $erros.='2º Ficheiro não foi enviado corretamente'; 
                }
            } else {
                $erros.= "Ficheiro ".$_FILES['ficheiro2']["name"]." muito grande<br>";           
            }
        }
        
        if (move_uploaded_file($_FILES["ficheiro3"]["tmp_name"], $target_file3)) {
            if ($_FILES["ficheiro3"]["size"] < 900000) {

                $sql=sprintf("update produtos set  ficheiro3='../%s' , nome_original3='%s' where id=%d;",$target_file3,$_FILES["ficheiro3"]["name"],$_POST['id']);
                if(!mysqli_query($ligacao,$sql)){
                    $erros.='3º Ficheiro não foi enviado corretamente'; 
                }
            } else {
                $erros.= "Ficheiro ".$_FILES['ficheiro3']["name"]." muito grande<br>";           
            }
        }
}

mysqli_set_charset($ligacao,'UTF8'); // DEFINE O CHARSET DO OUTPUT DE MYSQL

$sql_procura=sprintf("select * from produtos where id=%d;",$_POST['id']);
$res_procura=mysqli_query($ligacao,$sql_procura);
$reg_procura=mysqli_fetch_array($res_procura);

?>     

<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Landing PAGE Html5 Template">
    <meta name="keywords" content="landing,startup,flat">
    <meta name="author" content="Made By GN DESIGNS">

    <title>Begin Car - Vortex layout</title>

    <!-- // PLUGINS (css files) // -->
    <link href="assets/js/plugins/bootsnav_files/skins/color.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/animate.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/bootsnav.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/overwrite.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.theme.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.transitions.css" rel="stylesheet">
    <link href="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/magnific-popup.css" rel="stylesheet">
    <!--// ICONS //-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--// BOOTSTRAP & Main //-->
    <link href="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/main.css" rel="stylesheet">
</head>

<style>
    tab { padding-right: 100em; }  
</style>
    
<body>

    <!--======================================== 
           Preloader
    ========================================-->
    <div class="page-preloader">
        <div class="spinner">
            <div class="rect1"></div>
            <div class="rect2"></div>
            <div class="rect3"></div>
            <div class="rect4"></div>
            <div class="rect5"></div>
        </div>
    </div>
      <!--======================================== 
           Header
    ========================================-->

    <!--//** Navigation**//-->
    <nav data-minus-value-desktop="70" data-minus-value-mobile="55" data-speed="1000">

        <div class="container">
            <!-- Start Header Navigation -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" >
                    <img src="assets/img/begincar.png" class="logo" alt="logo" style="width: 150px;">
                </a>
            </div>
            <!-- End Header Navigation -->
        
                <form method="post" class="signup-form" enctype="multipart/form-data">
                    <div class="col-md-5 col-md-offset-1">
                        <h2 class="text-center">Editar Produtos</h2>
                        <hr>
                        <div class="form-group">
                            <input type="text" name="nome_prod" class="form-control" placeholder="Nome do Produto" required="required" value="<?php echo $reg_procura['nome_prod']; ?>">
                        </div>
                        <div class="form-group">
                            <input type="text" name="ref" class="form-control" placeholder="Referência" required="required" value="<?php echo $reg_procura['ref']; ?>">
                        </div>
                        <div class="form-group">
                            <input type="text" name="descricao" class="form-control" placeholder="Descrição" required="required" value="<?php echo $reg_procura['descricao']; ?>">
                        </div>
                        <div class="form-group">
                            <input type="text" name="preco" class="form-control" placeholder="Preço (em euros,'nao colocar simbolos')" required="required" value="<?php echo $reg_procura['preco']; ?>">
                        </div>
                        <div class="form-group">
                            <input type="text" name="stock" class="form-control" placeholder="Stock (unidades disponiveis)" required="required"value="<?php echo $reg_procura['stock']; ?>">
                        </div>
                        <div class="form-group">
                            <input type="hidden" name="id"  value="<?php echo $_POST['id'] ?>">  
                        </div>
                        <hr>
                            
                            <?php
                                if(isset($_POST['submeter'])){
                                    if($erros!=''){
                                        ?>
                                        <div class="alert alert-danger" align="center"><?php echo $erros ; ?></div>
                            <?php
                                    } else {
                                            $sql_inserir=sprintf("update produtos set nome_prod='%s', ref='%s', descricao='%s', preco='%s', stock='%s' where id=%d;", $_POST['nome_prod'], $_POST['ref'],$_POST['descricao'], $_POST['preco'], $_POST['stock'], $_POST['id']);
                                            if(mysqli_query($ligacao,$sql_inserir)){
                            ?>
                                                <div class="alert alert-success" align="center">
                                                <?php echo $sucesso='DADOS ENVIADOS COM SUCESSO'; ?>
                                                </div>
                            <?php
                                            } else {
                                                $erros='ERRO AO GUARDAR OS DADOS';
                            ?>                  <div class="alert alert-danger" align="center"><?php echo $erros ; ?></div><?php
                                            } 
                                    }
                                }
                            ?>
                    </div>
                    <div class="row" >
                    <h2 class="text-center">Imagens do Produto</h2>
                    <hr>
                
                    <h6 class="text-center"><b>Selecione o ficheiro da 1ª imagem:</b></h6>
                        <center><input type="file" name="ficheiro" class="btn standard-button" id="ficheiro"></center>
                <br>
                    <h6 class="text-center"><b>Selecione o ficheiro da 2ª imagem:</b></h6>
                        <center><input type="file" name="ficheiro2" class="btn standard-button" id="ficheiro2"></center>
                <br>
                    <h6 class="text-center"><b>Selecione o ficheiro da 3ª imagem:</b></h6>
                        <center><input type="file" name="ficheiro3" class="btn standard-button" id="ficheiro3"></center>
                    
            </div><br>
                    <div class="col-md-5 col-md-offset-3">
                        <div class="form-group text-center">
                            <button type="submit" name="submeter" class="btn btn-blue" style="width: 50%;">Enviar</button>
                        </div>
                    </div>
            </form>
        </div>
        <hr>
        <form class="contact-form" method="post">
            <?php
                if(isset($_POST['submeter'])){
                    if($erros==''){ 
            ?>
                <button type="submit" name="verif" class="btn btn-blue" style="width: 13%;">Verificar Alteração</button>
            <?php 
                    }
                }
            ?>
                 <button type="submit" name="back1" class="btn btn-blue" style="width: 10%;">Voltar</button>
        </form>
        
 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
    <script src="assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>
    <script src="assets/js/plugins/bootsnav_files/js/bootsnav.js"></script>
    <script src="assets/js/plugins/typed.js-master/typed.js-master/dist/typed.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js"></script>
    <script src="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
    <script src="assets/js/main.js"></script>
    </nav>
</body>
        
</html> 
     