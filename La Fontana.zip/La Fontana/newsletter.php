<!DOCTYPE html>
<?php
                if(isset($_POST['subscrever'])){ //if subscribe btn click
                    $userEmail = $_POST['email']; //receber o email do utilizador
                    if(filter_var($userEmail, FILTER_VALIDATE_EMAIL)) { //A validar o email
                        $subject = "Obrigado por subescrever ao nosso Newsletter!";
                        $message = "Obrigado por ter subescrevido a nossa página. Irá receber todos os updates do nosso delicioso menu.";
                        $sender = "Form: lafontana423@gmail.com"; //email que vai mandar a menssagem
                        if(mail()){

                        }else{
                        ?>
                        <div class="alert"> <?php echo $userEmail ?> Email invalido </div>
                        <?php 
                    }
                    
                }
                ?>